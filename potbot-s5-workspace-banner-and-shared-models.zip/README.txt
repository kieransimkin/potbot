# Potbot S5 — Workspace-aware agent Figlet banners

Latest checked public `main` commit: `13bd086851d92c9d1327c402728c3ba7ac094722` (`continue`). The new public changes since 9a0c9ed concern UI/Xpra; the existing backend file hashes modified by this patch still match. Both variants were application-tested against clean reconstructed source snapshots, not a direct network clone.

## Choose ONE patch

1. If S1–S4 is already applied (the `shared_model_library.py`, `shared_tool_store.py` and versioned rootfs are already in the worktree): use `potbot-s5-workspace-agent-banners-incremental.patch`.
2. If S1–S4 is **not** applied and the checkout is public `main`: use `potbot-s5-shared-workspace-models-banners-cumulative.patch` (includes the sandbox concurrency, shared tools, `/var/ai` and global model store changes).

Do not apply both. Do not apply older cumulative S1–S4 patches after S5.

PowerShell, from the repository directory:

    git switch main
    git pull --ff-only
    git status --short
    git apply --check .\SELECTED.patch
    git apply .\SELECTED.patch
    git diff --check
    uv run --locked python -m pytest -q tests/unit/test_agent_skeleton.py tests/unit/test_model_cache_routes.py

If `git apply --check` fails, stop and inspect the worktree; do not force it or overwrite unrelated files.

## Banner behavior

* Anonymous agent's home: `/home/<64-character sha256>`; banner displays the workspace's FIGlet-compatible name (ASCII-normalized and at most 48 characters).
* After the guarded rename: banner defaults to agent name (dashes/underscores displayed as spaces).
* Named agent may create `~/.config/potbot/banner.title` to override the title.
* `~/.config/potbot/banner.font`: standard, slant, small, big, shadow or banner.
* `~/.config/potbot/banner.color`: rainbow or plain.
* The three original pinned Kieran Simkin MOTD files remain byte-identical in agent homes. The interactive wrapper implements the dynamic FIGlet banner. Noninteractive Bash is silent.
* Existing customized skeleton v1–v3 homes are not overwritten automatically.

## Verification

* S5-only: git apply --check, actual git apply, reverse check, diff --check and 15 targeted tests passed on a clean S4 snapshot.
* S1–S5 cumulative: git apply --check, actual git apply, reverse check, diff --check and 64 targeted tests passed on clean reconstructed public backend source.
* Python compileall and Bash syntax passed.
* Original vendor MOTD scripts contain trailing blank lines: the cumulative patch can show two nonfatal git apply whitespace warnings, but the resulting worktree passes `git diff --check`.
* No real WSL2 Bubblewrap, PostgreSQL, model download, Docker Compose build/signing, Ruff or MyPy qualification is claimed.
