#!/usr/bin/env python3
"""S38 safe source installer. Requires S37; does not launch tools or contact GitHub.

Updates exact unique UTF-8 anchors, refuses dirty conflicting destinations, and
writes backups to private Git metadata. All changes are planned before writing.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path

BASE = "68d65e25f647652b4b4119495779ea8fb57e4cae"
ADDITIONS = (
    "src/potbot/tools/browser_session_leases.py",
    "src/potbot/tools/browser_gallery.py",
    "src/potbot/tools/browser_connect_gateway.py",
    "src/potbot/api/browser_gallery.py",
    "frontend/src/lib/server/browser-evidence.ts",
    "frontend/src/lib/server/xpra-leases.ts",
    "frontend/src/app/api/ui/browser/evidence/route.ts",
    "frontend/src/app/api/ui/browser/evidence/[id]/[part]/route.ts",
    "frontend/src/app/api/ui/xpra/apps/[sessionId]/lease/route.ts",
    "frontend/src/components/BrowserEvidenceGallery.tsx",
    "frontend/src/components/useBrowserLease.ts",
    "tests/unit/test_browser_s38.py",
    "frontend/tests/browser-s38.test.mjs",
    ".github/workflows/browser-s38.yml",
    "docs/implementation/38-browser-session-gallery-proxy.md",
)
REPLACEMENTS: dict[str, list[tuple[str,str]]] = {}


def patch(path: str, old: str, new: str) -> None:
    if not old or old == new:
        raise ValueError("invalid S38 source rule")
    REPLACEMENTS.setdefault(path, []).append((old, new))

# One exact source variant is accepted per upgraded integration seam.
VARIANTS: dict[str, list[tuple[tuple[str,str], ...]]] = {}

def variants(path: str, *choices: tuple[str,str]) -> None:
    if not choices or any(not old or old == new for old,new in choices):
        raise ValueError("invalid S38 integration variants")
    VARIANTS.setdefault(path, []).append(tuple(choices))


A = "src/potbot/tools/xpra_app_sessions.py"
patch(A, '                 max_apps: int = 4, max_age_seconds: int = 3600) -> None:',
      '                 browser_leases: Any = None,\n'
      '                 max_apps: int = 4, max_age_seconds: int = 3600) -> None:')
patch(A, '        self.max_apps, self.max_age_seconds = max_apps, max_age_seconds\n',
      '        if browser_leases is not None:\n'
      '            from potbot.tools.browser_session_leases import BrowserSessionCoordinator\n'
      '            if (not isinstance(browser_leases, BrowserSessionCoordinator)\n'
      '                    or browser_leases.workspace_id != workspace_id\n'
      '                    or browser_leases.principal_id != principal_id):\n'
      '                raise ScopeDeniedError("browser reservations differ from operator scope")\n'
      '        self.browser_leases = browser_leases\n'
      '        self.max_apps, self.max_age_seconds = max_apps, max_age_seconds\n')
patch(A, '    def browser_command(self, identifier: str, command: object) -> dict[str, Any]:\n',
      '    def browser_command(self, identifier: str, command: object,\n'
      '                        *, lease_token: str | None = None) -> dict[str, Any]:\n')
patch(A, '        try:\n            return channel.call(command)\n        except StateMismatchError:\n',
      '        try:\n'
      '            if self.browser_leases is None:\n'
      '                return channel.call(command)  # legacy operator-only profile\n'
      '            if lease_token is None:\n'
      '                raise ScopeDeniedError("browser requires its current exclusive reservation")\n'
      '            with self.browser_leases.operation(identifier, lease_token):\n'
      '                return channel.call(command)\n'
      '        except StateMismatchError:\n')
patch(A, '            with self._lock:\n                app.indeterminate = True\n                self._terminate(app)\n                self._settle()\n            raise\n\n    def fence_browser',
      '            with self._lock:\n                app.indeterminate = True\n'
      '                if self.browser_leases is not None:\n'
      '                    self.browser_leases.fence(identifier)\n'
      '                self._terminate(app)\n                self._settle()\n            raise\n\n    def fence_browser')
patch(A, '            app.indeterminate = True\n            self._terminate(app)\n            self._settle()\n\n    def detach',
      '            app.indeterminate = True\n'
      '            if self.browser_leases is not None:\n'
      '                self.browser_leases.fence(identifier)\n'
      '            self._terminate(app)\n            self._settle()\n\n    def detach')
patch(A, '    def browser_command(self, identifier: str, command: object,',
      '    def browser_reservation(self, identifier: str, action: str = "status",\n'
      '                            token: str | None = None) -> dict[str, Any]:\n'
      '        """Operator UI reservation boundary. Agent reservations stay on the host."""\n'
      '        with self._lock:\n'
      '            app = self._get(identifier)\n'
      '            if (app.recipe.kind != "controlled-browser" or app.process.poll() is not None\n'
      '                    or app.indeterminate):\n'
      '                raise CapabilityUnavailableError("controlled browser session unavailable")\n'
      '            if self.browser_leases is None:\n'
      '                if action in {"status", "acquire"}:\n'
      '                    return {"legacy": True, "reservation": {"sessionId": identifier,\n'
      '                            "reserved": False, "mode": "legacy"}}\n'
      '                raise ScopeDeniedError("legacy browser does not have a reservation token")\n'
      '            if action == "status":\n'
      '                return {"reservation": self.browser_leases.projection(identifier)}\n'
      '            if action == "acquire":\n'
      '                lease = self.browser_leases.reserve(\n'
      '                    identifier, owner_kind="operator", owner_id=self.principal_id)\n'
      '            elif action == "renew" and token is not None:\n'
      '                lease = self.browser_leases.renew(\n'
      '                    identifier, token, owner_kind="operator", owner_id=self.principal_id)\n'
      '            elif action == "release" and token is not None:\n'
      '                self.browser_leases.release(\n'
      '                    identifier, token, owner_kind="operator", owner_id=self.principal_id)\n'
      '                return {"reservation": self.browser_leases.projection(identifier)}\n'
      '            else:\n'
      '                raise ScopeDeniedError("browser reservation operation is unsupported")\n'
      '            if lease.owner_kind != "operator" or lease.owner_id != self.principal_id:\n'
      '                raise ScopeDeniedError("operator cannot take an agent-owned reservation")\n'
      '            return {"reservation": self.browser_leases.projection(identifier),\n'
      '                    "token": lease.token}\n\n'
      '    def browser_command(self, identifier: str, command: object,')
patch(A, '    def terminate(self, identifier: str) -> dict[str, Any]:\n        with self._lock:\n            app = self._get(identifier)\n            self._terminate(app)\n            self._settle()\n            return app.view().document()\n',
      '    def terminate(self, identifier: str) -> dict[str, Any]:\n'
      '        with self._lock:\n            app = self._get(identifier)\n'
      '            self._terminate(app)\n            self._settle()\n'
      '            if self.browser_leases is not None and app.recipe.kind == "controlled-browser":\n'
      '                self.browser_leases.retired(identifier, process_stopped=app.process.poll() is not None)\n'
      '            return app.view().document()\n')
# S36 already extends this policy with a 'logs' object, so this is an
# explicit two-version source rule rather than a silent fuzzy merge.
variants(A,
    (
        '        if not isinstance(data, dict) or set(data) != {"workspaceId", "principalId", "runtime", "ledger", "recipes"}:\n'
        '            raise ValueError()\n',
        '        allowed = {"workspaceId", "principalId", "runtime", "ledger", "recipes"}\n'
        '        if (not isinstance(data, dict) or set(data) not in (allowed, allowed | {"browserLeases"})\n'
        '                or ("browserLeases" in data and type(data["browserLeases"]) is not bool)):\n'
        '            raise ValueError()\n',
    ),
    (
        '        if not isinstance(data, dict) or (set(data) not in (\n'
        '                {"workspaceId", "principalId", "runtime", "ledger", "recipes"},\n'
        '                {"workspaceId", "principalId", "runtime", "ledger", "recipes", "logs"})):\n'
        '            raise ValueError()\n',
        '        allowed = {"workspaceId", "principalId", "runtime", "ledger", "recipes"}\n'
        '        allowed_with_logs = allowed | {"logs"}\n'
        '        if (not isinstance(data, dict) or set(data) not in (allowed, allowed_with_logs,\n'
        '                allowed | {"browserLeases"}, allowed_with_logs | {"browserLeases"})\n'
        '                or ("browserLeases" in data and type(data["browserLeases"]) is not bool)):\n'
        '            raise ValueError()\n',
    ),
)
patch(A, '        return XpraApplicationSupervisor(workspace_id=server.workspace_id, principal_id=principal,\n',
      '        from potbot.tools.browser_session_leases import BrowserSessionCoordinator\n'
      '        leases = (BrowserSessionCoordinator(server.workspace_id, principal)\n'
      '                  if data.get("browserLeases") is True else None)\n'
      '        return XpraApplicationSupervisor(workspace_id=server.workspace_id, principal_id=principal,\n')
patch(A, '                                         recipes=recipes, backend=xbackend, ledger=ledger,\n',
      '                                         recipes=recipes, backend=xbackend, ledger=ledger,\n'
      '                                         browser_leases=leases,\n')

S = "src/potbot/tools/x11_workspace_server.py"
patch(S, '    @app.post("/v1/xpra/apps/{session_id}/browser")\n',
      '    @app.get("/v1/xpra/apps/{session_id}/browser/lease")\n'
      '    def browser_lease_status(session_id: str, authorization: str | None = Header(default=None)) -> JSONResponse:\n'
      '        authenticate(authorization)\n'
      '        if apps is None:\n'
      '            raise HTTPException(503, "browser reservations not configured")\n'
      '        try:\n'
      '            result = apps.browser_reservation(session_id)\n'
      '        except (ValueError, RuntimeError, DomainError, OSError):\n'
      '            raise HTTPException(503, "browser reservation unavailable") from None\n'
      '        return JSONResponse({"workspaceId": str(server.workspace_id), **result},\n'
      '                            headers={"Cache-Control": "private, no-store"})\n\n'
      '    @app.post("/v1/xpra/apps/{session_id}/browser/lease")\n'
      '    async def browser_lease_update(session_id: str, request: Request,\n'
      '                                   authorization: str | None = Header(default=None)) -> JSONResponse:\n'
      '        authenticate(authorization)\n'
      '        if apps is None:\n'
      '            raise HTTPException(503, "browser reservations not configured")\n'
      '        if int(request.headers.get("content-length", "0") or "0") > 400:\n'
      '            raise HTTPException(413, "reservation request exceeds limit")\n'
      '        raw = await request.body()\n'
      '        if len(raw) > 400:\n'
      '            raise HTTPException(413, "reservation request exceeds limit")\n'
      '        try:\n'
      '            body = json.loads(raw)\n'
      '            if (not isinstance(body, dict) or body.get("action") not in {"acquire", "renew", "release"}\n'
      '                    or set(body) != ({"action"} if body.get("action") == "acquire" else {"action", "token"})):\n'
      '                raise ValueError()\n'
      '            result = apps.browser_reservation(session_id, body["action"], body.get("token"))\n'
      '        except (ValueError, RuntimeError, DomainError, OSError):\n'
      '            raise HTTPException(409, "reservation denied or fenced") from None\n'
      '        return JSONResponse({"workspaceId": str(server.workspace_id), **result},\n'
      '                            headers={"Cache-Control": "private, no-store"})\n\n'
      '    @app.post("/v1/xpra/apps/{session_id}/browser")\n')
patch(S, '            result = apps.browser_command(session_id, data)\n',
      '            lease_token = request.headers.get("x-potbot-browser-lease")\n'
      '            result = (apps.browser_command(session_id, data, lease_token=lease_token)\n'
      '                      if lease_token is not None else apps.browser_command(session_id, data))\n')

C = "src/potbot/controller/browser_cogs.py"
patch(C, 'from potbot.tools.browser_evidence import BrowserEvidenceRecorder, BrowserEvidenceScope\n',
      'from potbot.tools.browser_evidence import BrowserEvidenceRecorder, BrowserEvidenceScope\n'
      'from potbot.tools.browser_session_leases import BrowserLease\n'
      'from potbot.tools.browser_gallery import BrowserEvidenceGallery\n')
patch(C, '                 allow_model_preview: bool = False) -> None:\n',
      '                 allow_model_preview: bool = False,\n'
      '                 gallery: BrowserEvidenceGallery | None = None,\n'
      '                 reservations: tuple[BrowserLease, ...] = ()) -> None:\n')
patch(C, '        self.recorder = BrowserEvidenceRecorder(artifacts, actor)\n',
      '        self.recorder = BrowserEvidenceRecorder(artifacts, actor)\n'
      '        if gallery is not None and not isinstance(gallery, BrowserEvidenceGallery):\n'
      '            raise ScopeDeniedError("browser gallery is not an operator index")\n'
      '        if (not isinstance(reservations, tuple) or len(reservations) > 12 or\n'
      '                any(not isinstance(v, BrowserLease) or v.workspace_id != actor.workspace_id\n'
      '                        or v.owner_kind != "agent" or v.session_id not in self.approved_sessions\n'
      '                        for v in reservations) or len({v.session_id for v in reservations}) != len(reservations)):\n'
      '            raise ScopeDeniedError("browser reservations must be host-issued for this workspace")\n'
      '        if reservations and (apps.browser_leases is None):\n'
      '            raise ScopeDeniedError("agent browser reservations require the real Xpra coordinator")\n'
      '        self.gallery = gallery\n'
      '        self.reservations = {v.session_id: v for v in reservations}\n')
patch(C, '            raw = self.apps.browser_command(session, cmd)\n',
      '            reserved = self.reservations.get(session)\n'
      '            if reserved is not None:\n'
      '                raw = self.apps.browser_command(session, cmd, lease_token=reserved.token)\n'
      '            else:\n'
      '                raw = self.apps.browser_command(session, cmd)\n')
patch(C, '                command=cmd, result=raw, kind=kind, require_image=group == "capture",\n            )\n',
      '                command=cmd, result=raw, kind=kind, require_image=group == "capture",\n'
      '            )\n'
      '            if self.gallery is not None:\n'
      '                self.gallery.append(actor, BrowserEvidenceScope(\n'
      '                    workspace_id=actor.workspace_id, principal_id=actor.principal_id,\n'
      '                    session_id=session, invocation_id=invocation_id,\n'
      '                    policy_sha256=self.policy.fingerprint,\n'
      '                ), receipt)\n')

P = "src/potbot/api/server.py"
patch(P, '    worker_telemetry_reader: Any | None = None,\n    settings: ServerSettings = _DEFAULT_SETTINGS,\n',
      '    worker_telemetry_reader: Any | None = None,\n'
      '    browser_gallery: Any | None = None,\n    settings: ServerSettings = _DEFAULT_SETTINGS,\n')
patch(P, '    @app.get("/v1/system/utilisation")\n',
      '    if browser_gallery is not None:\n'
      '        from potbot.api.browser_gallery import install_gallery_routes\n'
      '        install_gallery_routes(app, context, browser_gallery)\n\n'
      '    @app.get("/v1/system/utilisation")\n')


CLI = "src/potbot/api/server_cli.py"
patch(CLI, '    app = create_app(\n',
      '    gallery_fields = (\n'
      '        "browser_gallery_index", "browser_artifact_root", "browser_rootfs",\n'
      '        "browser_home", "browser_model_staging", "browser_shared_tools",\n'
      '    )\n'
      '    configured = tuple(getattr(args, field, None) for field in gallery_fields)\n'
      '    browser_gallery = None\n'
      '    if any(path is not None for path in configured):\n'
      '        from potbot.domain.errors import InvalidInputError\n'
      '        from potbot.persistence.artifacts import ArtifactStore, LocalArtifactBackend\n'
      '        from potbot.tools.browser_gallery import BrowserEvidenceGallery\n'
      '        if any(path is None for path in configured):\n'
      '            raise InvalidInputError("Browser gallery needs all six explicit operator paths")\n'
      '        index, artifact_root, rootfs, home, staging, tools = configured\n'
      '        browser_gallery = BrowserEvidenceGallery(\n'
      '            index, ArtifactStore(database, LocalArtifactBackend(artifact_root)),\n'
      '            forbidden_roots=(rootfs, home, staging, tools, artifact_root),\n'
      '        )\n'
      '    app = create_app(\n')
patch(CLI, '        worker_telemetry_reader=monitor_reader,\n        settings=settings,\n',
      '        worker_telemetry_reader=monitor_reader,\n'
      '        browser_gallery=browser_gallery,\n        settings=settings,\n')
patch(CLI, '    parser.add_argument("--log-content", action="store_true",\n',
      '    parser.add_argument("--browser-gallery-index", type=Path,\n'
      '                        help="private derived SQLite browser index; requires all browser path flags")\n'
      '    parser.add_argument("--browser-artifact-root", type=Path,\n'
      '                        help="exact existing ArtifactStore local backend root")\n'
      '    parser.add_argument("--browser-rootfs", type=Path, help="qualified sandbox rootfs")\n'
      '    parser.add_argument("--browser-home", type=Path, help="workspace persistent home")\n'
      '    parser.add_argument("--browser-model-staging", type=Path, help="workspace model staging root")\n'
      '    parser.add_argument("--browser-shared-tools", type=Path, help="shared tool root")\n'
      '    parser.add_argument("--log-content", action="store_true",\n')

F = "frontend/src/lib/server/xpra-browser.ts"
patch(F, '  if (!appSessionId(sessionId)) return safeError("Invalid browser session.", 400);\n',
      '  if (!appSessionId(sessionId)) return safeError("Invalid browser session.", 400);\n'
      '  const reservation = request.headers.get("x-potbot-browser-lease");\n'
      '  if (reservation !== null && !/^[A-Za-z0-9_-]{32,128}$/.test(reservation))\n'
      '    return safeError("Invalid browser reservation.", 400);\n')
patch(F, '        Authorization: `Bearer ${config.secret}`, "Content-Type": "application/json",\n',
      '        Authorization: `Bearer ${config.secret}`, "Content-Type": "application/json",\n'
      '        ...(reservation ? {"X-Potbot-Browser-Lease": reservation} : {}),\n')

I = "frontend/src/components/BrowserInspector.tsx"
patch(I, 'import { useWorkspace } from "./WorkspaceContext";\n',
      'import { useWorkspace } from "./WorkspaceContext";\n'
      'import { useBrowserLease } from "./useBrowserLease";\n')
patch(I, '  const selected = sessions.find(s => s.id === sessionId)?.id ?? sessions[0]?.id ?? "";\n',
      '  const selected = sessions.find(s => s.id === sessionId)?.id ?? sessions[0]?.id ?? "";\n'
      '  const reservation = useBrowserLease(selected, workspace.id);\n')
patch(I, '    if (!selected) throw new Error("No controlled Chromium session");\n',
      '    if (!selected) throw new Error("No controlled Chromium session");\n'
      '    if (reservation.mode === "blocked" || reservation.mode === "connecting")\n'
      '      throw new Error("Browser exclusive reservation is not ready");\n')
patch(I, '      method: "POST", headers: { "Content-Type": "application/json", "x-potbot-workspace": workspace.id },\n',
      '      method: "POST", headers: { "Content-Type": "application/json", "x-potbot-workspace": workspace.id,\n'
      '        ...(reservation.token ? {"x-potbot-browser-lease": reservation.token} : {}) },\n')
patch(I, '  }, [selected, workspace.id]);\n',
      '  }, [selected, workspace.id, reservation.token, reservation.mode]);\n')
patch(I, '    <h3>Browser automation &amp; DevTools inspector</h3>\n',
      '    <h3>Browser automation &amp; DevTools inspector</h3>\n'
      '    <p role="status">{reservation.status}</p>\n')

V = "frontend/src/components/Panels.tsx"
patch(V, 'import { BrowserInspector } from "./BrowserInspector";\n',
      'import { BrowserInspector } from "./BrowserInspector";\n'
      'import { BrowserEvidenceGallery } from "./BrowserEvidenceGallery";\n')
patch(V, '      <BrowserInspector />\n',
      '      <BrowserInspector />\n      <BrowserEvidenceGallery />\n')


# No global CSS edit: existing browser-inspector / applications classes are reused.

def _hash(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _git_dir(worktree: Path) -> Path:
    cp = subprocess.run(["git", "-C", str(worktree), "rev-parse", "--absolute-git-dir"],
                        text=True, capture_output=True, check=False)
    if cp.returncode != 0:
        raise RuntimeError("destination must be an existing Git worktree")
    directory = Path(cp.stdout.strip())
    if not directory.is_dir():
        raise RuntimeError("Git metadata directory unavailable")
    return directory


def apply(target: Path, *, dry_run: bool = False) -> dict[str, object]:
    target = target.resolve(strict=True)
    git_dir = _git_dir(target)
    bundle = Path(__file__).resolve().parent
    # Source-only S37 precondition, no undocumented fallback to an older Cog API.
    for required in ("src/potbot/controller/browser_cogs.py", "src/potbot/tools/browser_evidence.py"):
        if not (target / required).is_file():
            raise RuntimeError("S38 requires the S37 browser Cog/evidence patch first")
    receipt_dir = git_dir / "potbot-backups" / "s38-browser-session-gallery"
    receipt = receipt_dir / "receipt.json"
    previous = json.loads(receipt.read_text()) if receipt.exists() else None
    paths = sorted(set(ADDITIONS) | set(REPLACEMENTS) | set(VARIANTS))
    additions: dict[str, bytes] = {}
    edits: dict[str, bytes] = {}
    originals: dict[str, bytes] = {}
    for name in paths:
        path = target / name
        if path.is_symlink() or any(p.is_symlink() for p in path.parents if p != target and target in p.parents):
            raise RuntimeError(f"redirected destination: {name}")
        if name in ADDITIONS:
            raw = (bundle / name).read_bytes()
            if path.exists() and path.read_bytes() != raw:
                raise RuntimeError(f"S38 refuses to overwrite {name}")
            additions[name] = raw
        else:
            if not path.is_file():
                raise RuntimeError(f"S38 missing source: {name}")
            original = path.read_bytes()
            content = original.decode("utf-8")
            for old, new in REPLACEMENTS[name]:
                if content.count(new) == 1:
                    continue
                if content.count(old) != 1:
                    raise RuntimeError(f"S38 source drift or ambiguous patch anchor: {name}")
                content = content.replace(old, new, 1)
            for choices in VARIANTS.get(name, []):
                if any(content.count(new) == 1 for old,new in choices):
                    continue
                matches = [(old,new) for old,new in choices if content.count(old) == 1]
                if len(matches) != 1:
                    raise RuntimeError(f"S38 source variant missing or ambiguous in {name}")
                old,new = matches[0]
                content = content.replace(old,new,1)
            edits[name] = content.encode("utf-8")
            originals[name] = original
    installed = {**edits, **additions}
    expected = {key: _hash(value) for key, value in installed.items()}
    if previous is not None:
        if previous.get("schema") != "potbot-s38-browser/v1" or previous.get("installed") != expected:
            raise RuntimeError("S38 receipt differs from the current source bundle")
    changes = {name: raw for name, raw in installed.items()
               if not (target/name).exists() or (target/name).read_bytes() != raw}
    if previous is not None and changes:
        raise RuntimeError("S38 installed sources have changed since the successful receipt")
    if dry_run:
        return {"schema":"potbot-s38-browser/v1", "dryRun":True,
                "changed":sorted(changes), "baseCommit":BASE}
    if changes:
        receipt_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
        os.chmod(receipt_dir, 0o700)
        for name in changes:
            out = target / name
            out.parent.mkdir(parents=True, exist_ok=True)
            if name in originals:
                backup = receipt_dir / (name.replace("/", "--") + ".bak")
                if backup.exists():
                    raise RuntimeError("pre-existing S38 backup requires operator reconciliation")
                backup.write_bytes(originals[name])
                os.chmod(backup, 0o600)
            temporary = out.with_name(out.name + ".s38-pending")
            if temporary.exists():
                raise RuntimeError("stale S38 pending file requires operator reconciliation")
            temporary.write_bytes(changes[name])
            os.replace(temporary, out)
    document: dict[str, object] = {"schema":"potbot-s38-browser/v1", "baseCommit":BASE,
                                   "installed":expected}
    if not receipt.exists():
        receipt_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
        fd = os.open(receipt, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        with os.fdopen(fd,"w") as writer:
            json.dump(document, writer, sort_keys=True, indent=2)
            writer.write("\n")
    return {"schema":"potbot-s38-browser/v1", "dryRun":False,
            "changed":sorted(changes), "baseCommit":BASE}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("worktree", type=Path)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    result = apply(args.worktree, dry_run=args.dry_run)
    print(json.dumps(result, sort_keys=True))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
