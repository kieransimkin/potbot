# Potbot S38 — browser session reservations, evidence gallery, CONNECT broker

Patch base: `main@68d65e25f647652b4b4119495779ea8fb57e4cae`.

**Prerequisite: apply S37 browser Cogs first.** S36 logging is compatible and recommended before host acceptance. S38 installer refuses a worktree without S37's files; no GitHub write access is needed.

```bash
python3 /path/to/potbot-s38-browser-control/install.py /path/to/potbot --dry-run
python3 /path/to/potbot-s38-browser-control/install.py /path/to/potbot
cd /path/to/potbot
PYTHONPATH=src python3 -m pytest -q tests/unit/test_browser_s38.py
cd frontend && npm install --no-audit --no-fund && npm run typecheck && npm test && npm run build
```

Original modified files are backed up under Git's private `potbot-backups/s38-browser-session-gallery/` metadata directory. Reapplying the same bundle is idempotent. Unknown/moved anchors and changed installed files are rejected instead of fuzzy merging. No host service, Chromium process, network proxy or sandbox is launched by the installer.

**Enable reservations separately:** add `"browserLeases": true` to the host-private Xpra application policy. Existing unreserved browser command paths then require valid tokens; the UI inspector acquires and renews an operator token. To expose the evidence gallery, construct `BrowserEvidenceGallery` outside guest filesystems with the existing `ArtifactStore` and inject it into both `BrowserControlService` and `potbot.api.server.create_app(browser_gallery=...)`, or start `potbot serve` using the six explicit flags `--browser-gallery-index`, `--browser-artifact-root`, `--browser-rootfs`, `--browser-home`, `--browser-model-staging`, `--browser-shared-tools`. See detailed instructions in `docs/implementation/38-browser-session-gallery-proxy.md`.

**Not yet enabled:** external Chromium network access. The new operator-private AF_UNIX CONNECT broker enforces an egress allowlist, but needs a separately qualified namespace-local forwarder; do not relax seccomp/network policy as part of S38 source application.

**Host qualification still required** for Xpra ownership, real RLS/artifact restart readback, browser input arbitration, TLS egress testing and S36 operator log monitoring.
