#!/usr/bin/env python3
"""Offline Node contract smoke for the shipped S38 frontend modules.

The test replaces ONLY the pre-existing Potbot auth/upstream/Xpra dependencies
with controlled no-network stubs. This is not a full Next.js production build.
"""
from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
runtime = root / "_fronttest"
for folder in (runtime / "src/lib/server", runtime / "src/lib", runtime / "tests"):
    folder.mkdir(parents=True, exist_ok=True)
for name in ("browser-evidence.ts", "xpra-leases.ts"):
    shutil.copyfile(root / "frontend/src/lib/server" / name, runtime / "src/lib/server" / name)
shutil.copyfile(root / "frontend/tests/browser-s38.test.mjs", runtime / "tests/browser-s38.test.mjs")
(runtime / "src/lib/server/security.ts").write_text('''
export function authConfig() { return {publicOrigin:'http://localhost:3100'}; }
export function sessionCookie() { return 'potbot_ui_session=test-session; SameSite=Strict'; }
export function safeError(message, status) {return Response.json({error: message}, {status});}
export function requireOperator(request) {return request.headers.get('cookie')?.includes('potbot_ui_session=test-session') ? authConfig() : safeError('Not authenticated',401); }
export function validOrigin(request, config) {return request.headers.get('origin')===config.publicOrigin;}
export async function boundedJSON(request,max) {const s=await request.text(); if(s.length>max) throw Error();return JSON.parse(s);}
''')
(runtime / "src/lib/server/potbot.ts").write_text('''
export function potbotConfigForRequest(request) {
 return request.headers.get('x-potbot-workspace')===process.env.POTBOT_UI_WORKSPACE_ID ?
 {base:'http://127.0.0.1:8760',token:'a'.repeat(40),workspaceId:process.env.POTBOT_UI_WORKSPACE_ID}:null;
}
export async function upstream(c,p,init={}) {return fetch(c.base+p,init);}
export function upstreamFailure(r) {return Response.json({error:'upstream failed'},{status:502});}
''')
(runtime / "src/lib/server/xpra-apps.ts").write_text('''
import {requireOperator,validOrigin,safeError} from './security.ts';
export function xpraAppScope(request, write=false) {
 const operator=requireOperator(request);if(operator instanceof Response)return operator;
 if(write&&!validOrigin(request,operator))return safeError('Invalid origin',403);
 const ws=request.headers.get('x-potbot-workspace');
 if(ws!==process.env.POTBOT_UI_WORKSPACE_ID)return safeError('Unknown workspace',404);
 return {base:'http://127.0.0.1:8765',secret:'s'.repeat(48),workspaceId:ws};
}
''')
(runtime / "src/lib/xpra-apps.ts").write_text('''
export function appSessionId(value) {return /^[a-f0-9]{32}$/.test(value);}
''')
result = subprocess.run(["node", "--experimental-strip-types", "--test",
                         "tests/browser-s38.test.mjs"], cwd=runtime, text=True,
                        capture_output=True, timeout=30)
print(result.stdout)
print(result.stderr, file=sys.stderr)
raise SystemExit(result.returncode)
