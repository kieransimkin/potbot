"""Exact-anchor worktree-install admission (synthetic source stubs only)."""
import importlib.util
import json
import subprocess
from pathlib import Path

import pytest

BUNDLE = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location("potbot_s38_installer", BUNDLE / "install.py")
installer = importlib.util.module_from_spec(spec)
assert spec.loader
spec.loader.exec_module(installer)


@pytest.mark.parametrize("with_logs", [False, True])
def test_dry_run_install_repeat_backups_and_drift(tmp_path: Path, with_logs: bool):
    repo = tmp_path / "worktree"
    repo.mkdir()
    subprocess.run(["git", "init", "-q", str(repo)], check=True)
    # Reconstruct only the exact expected anchors, not a fake running Potbot.
    for filename, rules in installer.REPLACEMENTS.items():
        raw = ""
        for index, (before, _) in enumerate(rules):
            if before not in raw and not any(before in after for _, after in rules[:index]):
                raw += "\n# Synthetic source input\n" + before
        path = repo / filename
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(raw)
    # Prior S36 changes the Xpra policy schema; the installer must accept each
    # explicit version but must not silently merge any unknown layout.
    for filename, groups in installer.VARIANTS.items():
        path = repo / filename
        layout = path.read_text()
        for alternatives in groups:
            layout += "\n# Upstream policy layout\n" + alternatives[int(with_logs)][0]
        path.write_text(layout)
    for required in ("src/potbot/controller/browser_cogs.py", "src/potbot/tools/browser_evidence.py"):
        path = repo / required
        path.parent.mkdir(parents=True, exist_ok=True)
        if not path.exists(): path.write_text("# S37 module present\n")
    dry = installer.apply(repo, dry_run=True)
    assert dry["dryRun"] is True
    assert set(dry["changed"]) == set(installer.ADDITIONS) | set(installer.REPLACEMENTS)
    assert not (repo / "src/potbot/tools/browser_gallery.py").exists()
    applied = installer.apply(repo)
    assert set(applied["changed"]) == set(dry["changed"])
    assert installer.apply(repo)["changed"] == []
    for path in installer.ADDITIONS:
        assert (repo / path).read_bytes() == (BUNDLE / path).read_bytes()
    git_dir = Path(subprocess.run(["git", "-C", str(repo), "rev-parse", "--absolute-git-dir"],
                                  capture_output=True, text=True, check=True).stdout.strip())
    receipt = git_dir / "potbot-backups/s38-browser-session-gallery/receipt.json"
    assert json.loads(receipt.read_text())["schema"] == "potbot-s38-browser/v1"
    assert len(list(receipt.parent.glob("*.bak"))) == len(installer.REPLACEMENTS)
    (repo / "src/potbot/tools/browser_gallery.py").write_text("changed-by-an-agent\n")
    with pytest.raises(RuntimeError, match="overwrite"):
        installer.apply(repo)


def test_missing_s37_never_creates_destinations(tmp_path: Path):
    repo = tmp_path / "worktree"
    repo.mkdir()
    subprocess.run(["git", "init", "-q", str(repo)], check=True)
    with pytest.raises(RuntimeError, match="S37"):
        installer.apply(repo, dry_run=True)
    assert not (repo / "src/potbot/tools/browser_gallery.py").exists()
