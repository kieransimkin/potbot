# Potbot S40 — AppView installer anchor repair (R3)

This package supersedes the previously issued `potbot-s40-agent-displays-fixed.zip`.
It targets merged S39 at `13f9b599a39da8e151106f680709de1c37f83061` and
contains the original S40 implementation plus a revised installer rule.

## Why the screenshot failed

The PowerShell variable `$zip` referred to `C:\Users\Kieran\Downloads\potbot-s40-agent-displays-fixed.zip`.
No file existed there; **opening a download link is not the same as extracting it**.
The separate `S40 ambiguous/divergent source ... return AppView(...)` error
came from an **already-extracted** installer folder that PowerShell successfully found.
The installer had an exact-text anchor for `_App.view()`; a wrapped/one-line
`AppView(...)` constructor has the same semantics but fails exact matching.

## Fastest repair: keep the existing installer folder

Download only the replacement `s40_rules_repair_r3.py` file from ChatGPT. Then run these commands
inside `C:\Users\Kieran\OneDrive\Documents\GitHub\potbot`:

```powershell
$destination = '..\potbot-s40-agent-displays-fixed\_rules.py'
if (-not (Test-Path -LiteralPath $destination -PathType Leaf)) { throw 'Old installer folder not found' }
$download = (Read-Host 'Paste the full path to the downloaded s40_rules_repair_r3.py').Trim('"')
if (-not (Test-Path -LiteralPath $download -PathType Leaf)) { throw "File does not exist: $download" }
Copy-Item -LiteralPath $destination -Destination "$destination.before-r3" -Force
Copy-Item -LiteralPath $download -Destination $destination -Force
python ..\potbot-s40-agent-displays-fixed\install.py . --dry-run
if ($LASTEXITCODE -ne 0) { throw 'S40 preflight still refused; do not apply; capture output' }
python ..\potbot-s40-agent-displays-fixed\install.py .
if ($LASTEXITCODE -ne 0) { throw 'S40 apply failed; stop and inspect errors' }
git diff --stat
```

Windows File Explorer's **Copy as path** menu gives the actual path to paste.
Do **not** execute `Expand-Archive` unless you downloaded the complete ZIP and
confirmed that the file really exists at `$zip`.

## Alternative: complete R3 ZIP

Download `potbot-s40-agent-displays-repaired.zip` through ChatGPT, reveal its
real location in File Explorer, and supply that exact absolute path to:

```powershell
$zip = (Read-Host 'Paste the full path to the downloaded S40 R3 ZIP').Trim('"')
if (-not (Test-Path -LiteralPath $zip -PathType Leaf)) { throw "ZIP missing: $zip" }
Expand-Archive -LiteralPath $zip -DestinationPath .. -Force
python ..\potbot-s40-agent-displays-repaired\install.py . --dry-run
if ($LASTEXITCODE -ne 0) { throw 'S40 preflight refused; stop' }
python ..\potbot-s40-agent-displays-repaired\install.py .
if ($LASTEXITCODE -ne 0) { throw 'S40 apply failed; stop' }
git diff --stat
```

## What was actually changed

`_rules.patch_app_view` inspects the AST **inside `_App.view()` only**. It
verifies a seven-field `AppView` constructor and changes only its `kind`
argument from `self.recipe.kind` to the new agent-aware ternary expression.
Both positional and named argument constructors are supported. Surrounding
comments, whitespace, line wrapping, non-ASCII content and CRLF are preserved.
The rule is idempotent. If `_App.view()` does something materially different,
it fails with a specific error instead of rewriting unfamiliar code.

The earlier AST fix for `XpraApplicationSupervisor.start()` is retained. Other
S40 edits retain strict anchors, so potentially unsafe source changes cannot
be overwritten. The full installer stages all changes after preflight, writes
backup files under Git metadata, and refuses symlinked destinations.

Tests: `python -m pytest -q tests/package/test_installer_s40.py` inside the
unpacked bundle. Real Linux Bubblewrap/Xpra and workspace security acceptance
must still run on the qualified host; source-level tests do not prove it.

If another preflight error occurs, capture its exact line and run:

```powershell
git status --short
git diff -- src/potbot/tools/xpra_app_sessions.py
Select-String -Path src/potbot/tools/xpra_app_sessions.py -Pattern 'return AppView' -Context 4,4
```

Do not use `git reset --hard` or apply an unreviewed force-patch.
