"""Offline S40 installer tests; synthetic S39 fixtures, never modify user trees."""
from __future__ import annotations

import ast
import importlib.util
import subprocess
from pathlib import Path

import pytest

BUNDLE = Path(__file__).resolve().parents[2]


def load(name: str, path: Path):
    import sys
    sys.path.insert(0, str(BUNDLE))
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def baseline_texts() -> dict[str, str]:
    # Earlier installer fixtures concatenated snippets into INVALID Python.
    # Keep old anchor strings in a module-level literal (still replaced by the
    # installer), but give start() an actual parseable method for AST tests.
    tree = ast.parse((BUNDLE / "_rules.py").read_text())
    assignments = [n for n in ast.walk(tree) if isinstance(n, ast.Assign) and
                   len(n.targets) == 1 and isinstance(n.targets[0], ast.Name) and
                   n.targets[0].id == "edits"]
    assert len(assignments) == 1
    fragments = [pair[0] for pair in ast.literal_eval(assignments[0].value)
                 if not pair[0].startswith('    def start(self, kind: str)')]
    assert len(fragments) > 15
    app = ("from __future__ import annotations\n"
           "S39_FRAGMENTS = '''\n" + "\n# isolated anchor\n".join(fragments) +
           '\n        optional = {"browserLeases", "strictXpraInput", "browserEgress"}\n' +
           "'''\n\nclass XpraApplicationSupervisor:\n"
           "    def start(self, kind: str) -> dict[str, Any]:\n"
           "        if not isinstance(kind, str) or kind not in self.recipes:\n"
           '            raise ScopeDeniedError("application kind is not on the operator allowlist")\n'
           "        with self._lock:\n"
           "            self._settle()\n"
           "            return {}\n"
           "\nclass _App:\n"
           "    def view(self):\n"
           "        state = 'running'\n"
           "        return AppView(self.id, self.recipe.kind, self.recipe.title,\n"
           "                       state, self.detached, self.started_at, None)\n")
    ast.parse(app)
    cogs = '                raw = self.apps.browser_command(session, cmd, lease_token=reserved.token)\n'
    policy = '    if "browserEgress" in raw and (not strict or not isinstance(raw["browserEgress"], dict)):\n'
    return {"src/potbot/tools/xpra_app_sessions.py": app,
            "src/potbot/controller/browser_cogs.py": cogs,
            "src/potbot/tools/browser_operator_policy.py": policy}


def fixture(tmp_path: Path, *, newline: str = "\n", s36: bool = False) -> Path:
    subprocess.run(["git", "init", "-q", str(tmp_path)], check=True)
    for req in ("src/potbot/tools/browser_session_leases.py",
                "src/potbot/tools/browser_connect_gateway.py",
                ".github/workflows/browser-s39.yml"):
        p = tmp_path / req
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text("# fixture\n")
    for rel, original in baseline_texts().items():
        if s36 and rel.endswith('xpra_app_sessions.py'):
            original = original.replace('"browserEgress"}', '"browserEgress", "logs"}')
        p = tmp_path / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(original.replace("\n", newline).encode())
    return tmp_path


def test_installer_applies_once_and_preserves_reapply(tmp_path: Path):
    installer = load("s40_install", BUNDLE / "install.py")
    repo = fixture(tmp_path)
    first = installer.planned_changes(repo)
    assert len(first) == len(installer.MODIFIED) + len(installer.NEW)
    installer.install(repo, first)
    assert installer.planned_changes(repo) == {}
    for rel in installer.MODIFIED:
        assert "agent" in (repo / rel).read_text()
    backup = repo / ".git" / "potbot-patches" / "s40-agent-xpra"
    assert any(backup.rglob("*.original"))


def test_crlf_and_s36_operator_allowlist_variant(tmp_path: Path):
    installer = load("s40_install_crlf", BUNDLE / "install.py")
    repo = fixture(tmp_path, newline="\r\n", s36=True)
    changes = installer.planned_changes(repo)
    installer.install(repo, changes)
    path = repo / "src/potbot/tools/xpra_app_sessions.py"
    text = path.read_bytes()
    assert b"\r\n" in text and b'"logs", "agentDisplays"' in text
    assert installer.planned_changes(repo) == {}


def test_unknown_drift_is_refused(tmp_path: Path):
    installer = load("s40_install_drift", BUNDLE / "install.py")
    repo = fixture(tmp_path)
    target = repo / "src/potbot/tools/xpra_app_sessions.py"
    target.write_text(target.read_text().replace('self.browser_leases = browser_leases',
                                                    'self.browser_leases = attacker_lease'))
    with pytest.raises(ValueError, match="divergent"):
        installer.planned_changes(repo)
    assert not (repo / "src/potbot/tools/agent_xpra_displays.py").exists()


def test_symlinks_in_new_destination_are_rejected(tmp_path: Path):
    installer = load("s40_install_symlink", BUNDLE / "install.py")
    repo = fixture(tmp_path)
    target = repo / "src/potbot/tools/agent_xpra_displays.py"
    target.symlink_to(repo / "src/potbot/tools/xpra_app_sessions.py")
    with pytest.raises(ValueError, match="symlink"):
        installer.planned_changes(repo)


def test_preexisting_start_error_message_and_comment_preserved(tmp_path: Path):
    installer = load("s40_installer_local_changes", BUNDLE / "install.py")
    repo = fixture(tmp_path)
    target = repo / "src/potbot/tools/xpra_app_sessions.py"
    previous = target.read_text()
    customized = previous.replace(
        'raise ScopeDeniedError("application kind is not on the operator allowlist")',
        'raise ScopeDeniedError("local operator: kind not approved")'
    ).replace('        with self._lock:\n',
              '        # Local operator safety note; preserve it.\n        with self._lock:\n')
    assert customized != previous
    target.write_text(customized)
    planned = installer.planned_changes(repo)
    installer.install(repo, planned)
    changed = target.read_text()
    assert 'local operator: kind not approved' in changed
    assert 'Local operator safety note; preserve it.' in changed
    assert 'agent GUI launch requires a qualified private display pool' in changed
    assert 'agent already has a live isolated Xpra browser' in changed
    assert installer.planned_changes(repo) == {}


def test_removed_kind_guard_fails_closed(tmp_path: Path):
    installer = load("s40_installer_bad_guard", BUNDLE / "install.py")
    repo = fixture(tmp_path)
    target = repo / "src/potbot/tools/xpra_app_sessions.py"
    target.write_text(target.read_text().replace(
        'if not isinstance(kind, str) or kind not in self.recipes:',
        'if kind == "unknown":',
    ))
    with pytest.raises(ValueError, match="validation was replaced"):
        installer.planned_changes(repo)


def test_partial_previous_agent_guard_fails_closed(tmp_path: Path):
    installer = load("s40_installer_partial_guard", BUNDLE / "install.py")
    repo = fixture(tmp_path)
    target = repo / "src/potbot/tools/xpra_app_sessions.py"
    target.write_text(target.read_text().replace('        with self._lock:\n',
        '        if agent_id is not None:\n'
        '            raise ScopeDeniedError("agent GUI launch requires a qualified private display pool")\n'
        '        with self._lock:\n'))
    with pytest.raises(ValueError, match="partially applied"):
        installer.planned_changes(repo)


def test_existing_app_view_one_line_and_multiline_variants(tmp_path: Path):
    """Regresses the exact return AppView(...) failure reported on Windows."""
    installer = load("s40_appview_variants", BUNDLE / "install.py")
    baseline = fixture(tmp_path)
    target = baseline / "src/potbot/tools/xpra_app_sessions.py"
    old = target.read_text()
    former = ('        return AppView(self.id, self.recipe.kind, self.recipe.title,\n'
              '                       state, self.detached, self.started_at, None)\n')
    assert former in old
    cases = (
        '        return AppView(self.id, self.recipe.kind, self.recipe.title, state, self.detached, self.started_at, None)\n',
        '        return AppView(\n            self.id,\n            self.recipe.kind,\n            self.recipe.title,\n            state,\n            self.detached,\n            self.started_at,\n            None,\n        )\n',
        '        # Côté navigateur: preserve this comment.\n'
        '        return AppView( self.id, self.recipe.kind, self.recipe.title,\n'
        '                        state, self.detached, self.started_at, None )\n',
        '        return AppView(\n'
        '            id=self.id, kind=self.recipe.kind, title=self.recipe.title,\n'
        '            state=state, detached=self.detached, started_at=self.started_at, exit_code=None\n'
        '        )\n',
    )
    from _rules import patch_app_view
    for variation in cases:
        source = old.replace(former, variation)
        assert source != old
        altered = patch_app_view(source, str(target))
        assert '"agent-browser" if self.agent_id is not None else self.recipe.kind' in altered
        assert patch_app_view(altered, str(target)) == altered
        ast.parse(altered)
        if 'Côté navigateur' in variation:
            assert 'Côté navigateur' in altered
    target.write_text(old.replace(former, cases[0]))
    changes = installer.planned_changes(baseline)
    assert "src/potbot/tools/xpra_app_sessions.py" in changes
    installer.install(baseline, changes)
    assert installer.planned_changes(baseline) == {}


def test_app_view_modified_kind_fails_closed(tmp_path: Path):
    installer = load("s40_kind_guard", BUNDLE / "install.py")
    repo = fixture(tmp_path)
    target = repo / "src/potbot/tools/xpra_app_sessions.py"
    target.write_text(target.read_text().replace(
        "AppView(self.id, self.recipe.kind, self.recipe.title,",
        "AppView(self.id, request.kind, self.recipe.title,",
    ))
    with pytest.raises(ValueError, match="kind expression changed"):
        installer.planned_changes(repo)
    assert not (repo / "src/potbot/tools/agent_xpra_displays.py").exists()
