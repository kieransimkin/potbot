#!/usr/bin/env python3
"""S41 installer: exact source-aware, all-files preflight and atomic rollback.

Targets merged S40+S14 main (ba8e413d) and permits harmless formatting changes.
Does not run git, shell scripts, tests, or publish branches. New files are
create-only, existing files are modified only at validated named locations.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PAYLOAD = ROOT / "payload"


def insert_in_class(source: str, class_name: str, method_name: str, code: str) -> str:
    """Insert one trusted method before a precise AST class method, never text-match body."""
    tree = ast.parse(source)
    classes = [x for x in tree.body if isinstance(x, ast.ClassDef) and x.name == class_name]
    if len(classes) != 1:
        raise ValueError(f"expected one {class_name} class")
    funcs = [x for x in classes[0].body if isinstance(x, (ast.FunctionDef, ast.AsyncFunctionDef))
             and x.name == method_name]
    if len(funcs) != 1:
        raise ValueError(f"expected one {class_name}.{method_name}")
    loc = min([funcs[0].lineno, *(d.lineno for d in funcs[0].decorator_list)])
    lines = source.splitlines(keepends=True)
    lines.insert(loc - 1, code.rstrip() + "\n\n")
    return "".join(lines)


def replace_once(source: str, anchor: str, replacement: str, target: str) -> str:
    if source.count(anchor) != 1:
        raise ValueError(f"{target}: required structural anchor is missing or ambiguous")
    return source.replace(anchor, replacement, 1)


def replace_line_once(source: str, anchor: str, replacement: str, target: str) -> str:
    """Replace a complete source line, never a suffix of a more-indented line.

    The legacy installer counted four-space substrings inside six-space
    callback lines. A structural line match must include leading indentation.
    The input has already been normalized to LF in main().
    """
    if not anchor.endswith("\n") or not replacement.endswith("\n"):
        raise ValueError(f"{target}: invalid line-edit specification")
    lines = source.splitlines(keepends=True)
    indices = [i for i, line in enumerate(lines) if line.rstrip() == anchor.rstrip()]
    if len(indices) != 1:
        raise ValueError(f"{target}: required whole-line anchor is missing or ambiguous")
    lines[indices[0]] = replacement
    return "".join(lines)


def patch_pool(source: str) -> str:
    if "def protocol_socket(self, agent_id: UUID)" in source:
        if ("private readonly Xpra display is unavailable" not in source or
                "return display.server.xpra_protocol_socket" not in source):
            raise ValueError("agent display S41 partial integration detected")
        return source
    code = '''    # S41: do not create or reassign a display for a viewing request.
    def protocol_socket(self, agent_id: UUID) -> Path:
        self._agent(agent_id)
        with self._lock:
            display = self._displays.get(agent_id)
            if display is None or display.server.readonly_mode is not True:
                raise CapabilityUnavailableError("private readonly Xpra display is unavailable")
            display.server.environment()
            return display.server.xpra_protocol_socket
'''
    result = insert_in_class(source, "AgentXpraDisplayPool", "retire", code)
    ast.parse(result)
    return result


def patch_apps(source: str) -> str:
    if "def agent_display_inventory(self)" in source:
        if "def agent_stream_socket(self, agent_id: UUID, identifier: str)" not in source:
            raise ValueError("agent supervisor S41 partial integration detected")
        return source
    code = '''    # S41: host/operator display inventory, never a model browser control port.
    def agent_display_inventory(self) -> list[dict[str, Any]]:
        if self.operator_attachment is not None:
            self.operator_attachment.require_healthy()
        if (self.agent_displays is None or self.browser_leases is None or not self.backend.server.readonly_mode
                or self._guard is None or self._guard.fenced):
            return []
        with self._lock:
            sessions = []
            for app in self._apps.values():
                if (app.agent_id is None or app.recipe.kind != "controlled-browser"
                        or app.process.poll() is not None or app.indeterminate):
                    continue
                # A failed display-health check must not appear as a live view.
                try:
                    self.agent_displays.environment(app.agent_id)
                except (OSError, RuntimeError):
                    continue
                sessions.append({"id": app.id, "agentId": str(app.agent_id),
                                 "title": app.recipe.title, "state": "running",
                                 "startedAt": app.started_at, "viewOnly": True})
            return sessions[-12:]

    def agent_stream_socket(self, agent_id: UUID, identifier: str) -> Path:
        if not isinstance(agent_id, UUID) or self.agent_displays is None or self.browser_leases is None:
            raise ScopeDeniedError("agent Xpra stream not configured")
        if self.operator_attachment is not None:
            self.operator_attachment.require_healthy()
        with self._lock:
            app = self._get(identifier)
            if (app.agent_id != agent_id or app.recipe.kind != "controlled-browser"
                    or app.indeterminate or app.process.poll() is not None
                    or self._guard is None or self._guard.fenced):
                raise ScopeDeniedError("agent display/session binding is not live")
            return self.agent_displays.protocol_socket(agent_id)
'''
    result = insert_in_class(source, "XpraApplicationSupervisor", "agent_sessions", code)
    ast.parse(result)
    return result


def patch_server(source: str) -> str:
    if '"/v1/xpra/agent/ws"' in source:
        if not all(endpoint in source for endpoint in (
                '/v1/xpra/agent-sessions',
                '/v1/xpra/agent-sessions/{agent_id}/{session_id}/ticket',
                'agent_streams.still_live(ticket)')):
            raise ValueError("Xpra service S41 partial integration detected")
        return source
    # Create one capability authority when explicit private display isolation is
    # active. Ordinary operator Xpra servers remain unchanged.
    anchor = '    from potbot.domain.errors import DomainError\n'
    init = '''    from potbot.domain.errors import DomainError
    # S41 operator-only read-only agent-view admission.
    agent_streams = None
    if apps is not None and getattr(apps, "agent_displays", None) is not None:
        from potbot.tools.agent_xpra_streams import AgentXpraTicketAuthority
        agent_streams = AgentXpraTicketAuthority(server, apps)
'''
    source = replace_once(source, anchor, init, "Xpra create_app authority")
    mark = '    @app.websocket("/v1/xpra/ws")\n'
    code = '''    # S41: these endpoints never expose agent browser RPC or session tokens.
    @app.get("/v1/xpra/agent-sessions")
    def agent_xpra_inventory(authorization: str | None = Header(default=None)) -> JSONResponse:
        authenticate(authorization)
        if agent_streams is None:
            result = {"workspaceId": str(server.workspace_id), "viewOnly": True, "sessions": []}
        else:
            try:
                result = agent_streams.inventory()
            except (OSError, RuntimeError, DomainError):
                raise HTTPException(503, "agent display inventory unavailable") from None
        return JSONResponse(result, headers={"Cache-Control": "private, no-store"})

    @app.post("/v1/xpra/agent-sessions/{agent_id}/{session_id}/ticket")
    async def agent_xpra_ticket(agent_id: str, session_id: str, request: Request,
                                authorization: str | None = Header(default=None)) -> JSONResponse:
        authenticate(authorization)
        if agent_streams is None:
            raise HTTPException(503, "agent stream admission is not enabled")
        # Refuse arbitrary request bodies and hidden control parameters.
        if request.query_params:
            raise HTTPException(400, "agent stream tickets accept no query parameters")
        async for chunk in request.stream():
            if chunk:
                raise HTTPException(400, "agent stream tickets accept no request payload")
        try:
            agent_uuid = UUID(agent_id)
            if str(agent_uuid) != agent_id:
                raise ValueError()
            result = agent_streams.issue(agent_uuid, session_id)
        except (ValueError, RuntimeError, DomainError, OSError):
            raise HTTPException(404, "agent browser is unavailable") from None
        return JSONResponse(result, headers={"Cache-Control": "private, no-store"})

    @app.websocket("/v1/xpra/agent/ws")
    async def agent_xpra_websocket(ws: WebSocket) -> None:
        if ws.headers.get("origin") != allowed_origin or agent_streams is None or (
            operator_fence is not None and not operator_fence.healthy()
        ):
            await ws.close(code=4403)
            return
        try:
            ticket = agent_streams.consume(ws.query_params.get("ticket", ""))
            upstream = await websockets.unix_connect(
                str(ticket.socket), uri="ws://localhost/", open_timeout=5,
                max_size=8 * 1024 * 1024, max_queue=4, compression=None,
            )
        except (OSError, RuntimeError, TimeoutError, DomainError):
            await ws.close(code=4403)
            return
        # Recheck after the connect syscall as well as before; the pathname
        # must not have been rebound during WebSocket handshaking.
        if not agent_streams.still_live(ticket):
            await upstream.close()
            await ws.close(code=4403)
            return
        await ws.accept()

        async def native_to_agent() -> None:
            while True:
                message = await ws.receive()
                if message["type"] == "websocket.disconnect":
                    return
                data = message.get("bytes")
                if not isinstance(data, bytes) or len(data) > 8 * 1024 * 1024:
                    return
                await upstream.send(data)

        async def agent_to_native() -> None:
            async for packet in upstream:
                if not isinstance(packet, bytes) or len(packet) > 8 * 1024 * 1024:
                    return
                await ws.send_bytes(packet)

        async def check_owner() -> None:
            # Tickets expire after admission; active relays also stop on agent
            # process retirement, private socket replacement, or operator loss.
            while True:
                await asyncio.sleep(0.25)
                if operator_fence is not None and not await asyncio.to_thread(operator_fence.healthy):
                    return
                if not await asyncio.to_thread(agent_streams.still_live, ticket):
                    return

        tasks = [asyncio.create_task(native_to_agent()),
                 asyncio.create_task(agent_to_native()), asyncio.create_task(check_owner())]
        try:
            done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
            for task in pending:
                task.cancel()
            await asyncio.gather(*pending, return_exceptions=True)
            for task in done:
                task.exception()
        except (WebSocketDisconnect, OSError, RuntimeError):
            pass
        finally:
            await upstream.close()
            try:
                await ws.close()
            except RuntimeError:
                pass

'''
    source = replace_once(source, mark, code+mark, "Xpra read-only agent relay")
    ast.parse(source)
    return source


def patch_contract(source: str) -> str:
    old = 'ws.pathname !== "/v1/xpra/ws"'
    new = '!["/v1/xpra/ws", "/v1/xpra/agent/ws"].includes(ws.pathname)'
    if new in source: return source
    return replace_once(source, old, new, "agent Xpra one-use frame URL")


def patch_orb(source: str) -> str:
    if "AgentXpraStreamHost" in source:
        markers = (
            '"agent-xwindow": AgentXpraWindowPanel,',
            'const agentHub = useAgentXpra();',
            'agentHub.openActiveWindows();',
            'agentHub.manuallyHidden(panel.id);',
            'new AgentXpraHub(workspace?.id ?? "")',
            '<AgentXpraProvider value={agentHub}>',
            '<AgentXpraStreamHost workspaceId={workspace.id}',
            '</AgentXpraProvider>',
        )
        if not all(m in source for m in markers):
            raise ValueError("Orb S41 partial integration detected; inspect before retrying")
        return source
    source = replace_once(source, 'import { XpraApplicationsPanel } from "./XpraApplicationsPanel";\n',
        'import { XpraApplicationsPanel } from "./XpraApplicationsPanel";\n'
        'import { AgentXpraHub } from "@/lib/agent-xpra-hub";\n'
        'import { AgentXpraProvider, AgentXpraStreamHost, AgentXpraWindowPanel, useAgentXpra } from "./AgentXpraStreams";\n', "Orb agent viewer imports")
    source = replace_once(source, 'applications: XpraApplicationsPanel, activity: ActivityPanel, xwindow: XpraWindowPanel,',
        'applications: XpraApplicationsPanel, activity: ActivityPanel, xwindow: XpraWindowPanel,\n  "agent-xwindow": AgentXpraWindowPanel,', "Orb Dockview window factory")
    source = replace_once(source, '  const apiRef = useDockApi();\n',
        '  const apiRef = useDockApi();\n  const agentHub = useAgentXpra();\n',
        "Dockview private browser hub")
    source = replace_line_once(source, '    onGraphMinimized(!api.getPanel("graph"));\n',
        '    onGraphMinimized(!api.getPanel("graph"));\n    agentHub.openActiveWindows();\n',
        "Dockview private-browser reconciliation")
    source = replace_once(source, '          onXWindowHidden(panel.id.slice(4));\n',
        '          onXWindowHidden(panel.id.slice(4));\n'
        '        if (panel.id.startsWith("agentx11:")) agentHub.manuallyHidden(panel.id);\n',
        "Dockview private-browser pane hiding")
    source = replace_once(source, '}, [apiRef, workspace.id, onGraphMinimized, onXWindowHidden]);',
        '}, [apiRef, workspace.id, onGraphMinimized, onXWindowHidden, agentHub]);',
        "Dockview private-browser lifecycle dependencies")
    source = replace_once(source, '  const workspace = workspaces[selected];\n',
        '  const workspace = workspaces[selected];\n'
        '  // S41: the agent window registry is scoped to one active workspace.\n'
        '  const agentHub = useMemo(() => new AgentXpraHub(workspace?.id ?? ""), [workspace?.id]);\n',
        "Orb workspace registry")
    source = replace_once(source, '  return <WorkspaceProvider value={session}>\n',
        '  return <WorkspaceProvider value={session}>\n    <AgentXpraProvider value={agentHub}>\n',
        "Orb agent provider start")
    source = replace_once(source, '      <DockApiContext.Provider value={apiRef}>\n',
        '      <DockApiContext.Provider value={apiRef}>\n'
        '        {!demo && <AgentXpraStreamHost workspaceId={workspace.id} enabled={gateway === "ready"} apiRef={apiRef}/>}\n',
        "Orb agent decoder host")
    source = replace_once(source, '  </WorkspaceProvider>;\n',
        '    </AgentXpraProvider>\n  </WorkspaceProvider>;\n', "Orb agent provider end")
    return source


def patch_apps_panel(source: str) -> str:
    if "AgentXpraApplications" in source:
        return source
    source = replace_once(source, 'import { DockControls } from "./Panels";\n',
        'import { DockControls } from "./Panels";\n'
        'import { AgentXpraApplications } from "./AgentXpraStreams";\n', "agent app manager import")
    source = replace_once(source, '    <div className="applications-search">',
        '    <AgentXpraApplications />\n    <div className="applications-search">',
        "agent app manager placement")
    return source

MODIFIED = {
    "src/potbot/tools/agent_xpra_displays.py": patch_pool,
    "src/potbot/tools/xpra_app_sessions.py": patch_apps,
    "src/potbot/tools/x11_workspace_server.py": patch_server,
    "frontend/src/lib/xpra-contract.ts": patch_contract,
    "frontend/src/components/OrbWorkspace.tsx": patch_orb,
    "frontend/src/components/XpraApplicationsPanel.tsx": patch_apps_panel,
}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repository", type=Path)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    repo = args.repository.resolve(strict=True)
    if not repo.is_dir() or not (repo / "src/potbot/tools/agent_xpra_displays.py").is_file():
        parser.error("must target the root of a checkout with merged S40 agent displays")
    if not (repo / ".git").exists():
        parser.error("must target a Git worktree, not the extracted patch directory")
    git = subprocess.run(["git", "rev-parse", "--absolute-git-dir"], cwd=repo,
                         capture_output=True, text=True, check=False)
    if git.returncode != 0:
        parser.error("repository is not a valid Git worktree")
    gitdir = Path(git.stdout.strip())
    if not gitdir.is_dir() or gitdir.is_symlink():
        parser.error("Git metadata directory is not a real directory")

    def checked_file(target: Path) -> None:
        cursor = target
        while cursor != repo:
            if cursor.is_symlink():
                raise ValueError(f"refusing symlink in destination {target.relative_to(repo)}")
            cursor = cursor.parent
    staged: dict[Path, bytes] = {}
    original: dict[Path, bytes | None] = {}
    changes: list[str] = []
    try:
        # PREPARE every file first. No writes if any source differs from the contract.
        for relative, function in MODIFIED.items():
            target = repo / relative
            checked_file(target)
            if target.is_symlink() or not target.is_file():
                raise ValueError(f"{relative} is missing or redirected")
            prior = target.read_bytes()
            text = prior.decode("utf-8")
            crlf = b"\r\n" in prior
            after = function(text.replace("\r\n", "\n")).encode("utf-8")
            if crlf: after = after.replace(b"\n", b"\r\n")
            original[target] = prior
            if after != prior:
                staged[target] = after
                changes.append(f"modify {relative}")
        for file in sorted(PAYLOAD.rglob("*")):
            if not file.is_file(): continue
            relative = file.relative_to(PAYLOAD).as_posix()
            dest = repo / relative
            checked_file(dest)
            data = file.read_bytes()
            if dest.is_symlink() or (dest.exists() and not dest.is_file()):
                raise ValueError(f"{relative} has a disallowed existing file type")
            prior = dest.read_bytes() if dest.exists() else None
            original[dest] = prior
            if prior is None:
                changes.append(f"create {relative}")
                staged[dest] = data
            elif prior != data:
                raise ValueError(f"{relative} differs from the reviewed S41 new file")
        print(f"S41 preflight: {len(changes)} file(s) to update; no source conflicts")
        for label in changes: print("  "+label)
        if args.dry_run or not staged:
            return 0
        # Backup and replace safely. Every edited file has its exact preimage
        # preserved before the first write; restore on an installation failure.
        backup_root = gitdir / "potbot-s41-backup" / str(time.time_ns())
        backup_root.mkdir(parents=True, exist_ok=False)
        for target, data in original.items():
            if data is not None and target in staged:
                dest = backup_root / target.relative_to(repo)
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(data)
        changed: list[Path] = []
        try:
            for target, data in staged.items():
                target.parent.mkdir(parents=True, exist_ok=True)
                with tempfile.NamedTemporaryFile(dir=target.parent, delete=False) as output:
                    output.write(data); output.flush(); os.fsync(output.fileno())
                    temp = Path(output.name)
                if target.exists():
                    os.chmod(temp, stat.S_IMODE(target.stat().st_mode))
                try:
                    os.replace(temp, target)
                finally:
                    temp.unlink(missing_ok=True)
                changed.append(target)
        except BaseException:
            for target in reversed(changed):
                prior = original[target]
                if prior is None: target.unlink(missing_ok=True)
                else: target.write_bytes(prior)
            raise
        print(f"S41 installed {len(staged)} files. Backup: {backup_root}")
        return 0
    except (OSError, UnicodeError, ValueError, SyntaxError) as error:
        print(f"S41 refused: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
