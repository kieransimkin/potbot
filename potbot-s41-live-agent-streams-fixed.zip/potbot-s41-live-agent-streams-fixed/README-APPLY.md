# S41 — Agent Xpra streaming into Dockview (installer-repaired release)

S41 installer fix checked against Potbot GitHub `main` **4f1c6ace2b0b4cf0135ec8d29619d69ffdf21d9d** (27 October 2026). That branch has also added S15 GUI kernel-auditing updates to several backend files; all S41 insertion anchors in the current GitHub tree were inspected. The repaired installer still refuses unexpected local modifications rather than overwriting them. No older S41 patch installers are needed.

This archive fixes the original S41 installer's Dockview reconciliation failure (the `onGraphMinimized` substring matched both a six-space layout callback and a four-space initialization line). The repaired installer uses a *whole-line* match, and refuses partially applied Orb integration instead of treating an imported symbol as success. The complete S41 payload also adds host-only, read-only agent-Xpra stream ticket admission, a separate authenticated native WebSocket relay, independently decoded frames and Dockview panes for each agent browser, and operator UI inventory. S40's per-agent Xpra display pool remains the authority to start processes; S41 does not create a new agent, browser or service credential from HTTP.

## Install on Windows/PowerShell

1. Download the ZIP to **any real local path**; don't assume the file is in `Downloads` or in the repository parent. Keep it outside the Git working tree.
2. From the `potbot` repo root, paste the commands below. The dry run must succeed before installing.

```powershell
$zip = (Read-Host 'Paste the full saved S41 ZIP path').Trim('"')
if (!(Test-Path -LiteralPath $zip -PathType Leaf)) { throw "ZIP not found: $zip" }

$parent = Split-Path -Parent (Get-Location).Path
Expand-Archive -LiteralPath $zip -DestinationPath $parent -Force
$installer = Join-Path $parent 'potbot-s41-live-agent-streams-fixed\install.py'
if (!(Test-Path -LiteralPath $installer -PathType Leaf)) { throw "Installer not extracted: $installer" }

python $installer . --dry-run
if ($LASTEXITCODE -ne 0) { throw 'S41 preflight failed: no files written' }
python $installer .
if ($LASTEXITCODE -ne 0) { throw 'S41 application failed' }

git diff --check
git diff --stat
```

The installer preflights all six modified files and all new files before writing, rejects redirected symlink targets or existing conflicting files, retains the original line-ending convention, writes original-file backups under the *actual* Git metadata directory, and supports repeat application. The Python edits select the exact `AgentXpraDisplayPool` and `XpraApplicationSupervisor` methods using the Python syntax tree. The frontend patches check distinct, unique source anchors; an incompatible worktree is rejected rather than overwritten.

## Qualification

```bash
PYTHONPATH=src python -m pytest -q tests/unit/test_agent_xpra_streams_s41.py \
  tests/unit/test_agent_xpra_displays_s40.py tests/unit/test_xpra_application_sessions.py \
  tests/unit/test_xpra_operator_fence_s14.py tests/integration/test_xpra_native_bridge.py
cd frontend
npm test && npm run typecheck && npm run build
```

The new `agent-xpra-s41.yml` workflow runs these on CI. Manual Linux/WSL2 host validation is **still mandatory**: bring up two enrolled agents, start their browsers via the S40 trusted host runner, view two separate Xpra windows with colliding numeric X11 window IDs, deny nonoperator and cross-agent session tickets, verify websocket owner-epoch cancellation, ensure both private X11 displays are `--readonly=yes`, and check cleanup after a crashed browser process. Unit tests and synthetic frames are not proof of kernel isolation.

See `docs/implementation/43-s41-agent-xpra-dockview.md` for the precise security contract and limitations.

## Already extracted the older S41 bundle?

You do **not** need to extract a second ZIP. Download the standalone repaired `install.py` from this response and save it as a file. While inside the `potbot` repository, replace the old installer **in the extracted S41 folder**:

```powershell
$source = (Read-Host 'Paste the downloaded fixed install.py full path').Trim('"')
$installer = '..\potbot-s41-live-agent-streams\install.py'
if (!(Test-Path -LiteralPath $source -PathType Leaf)) { throw 'Repaired installer download not found' }
if (!(Test-Path -LiteralPath $installer -PathType Leaf)) { throw 'Original S41 folder is missing' }
Copy-Item -LiteralPath $installer -Destination "$installer.before-fix" -Force
Copy-Item -LiteralPath $source -Destination $installer -Force
python $installer . --dry-run
if ($LASTEXITCODE -ne 0) { throw 'Preflight failed: do not install' }
python $installer .
if ($LASTEXITCODE -ne 0) { throw 'Install failed' }
git diff --check
git diff --stat
```

The repaired `install.py` is self-contained *as the S41 installer* but still requires the `payload` directory beside it. The previous failed dry-run did not modify Potbot. Do not copy these installer files into `src/potbot`.
