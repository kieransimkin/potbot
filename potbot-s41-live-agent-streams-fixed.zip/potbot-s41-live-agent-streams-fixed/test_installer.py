"""Run directly with pytest in the source bundle, independent of an installed repo."""
from pathlib import Path
import importlib.util
import subprocess
import sys

import pytest

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location("s41_installer",ROOT/"install.py")
installer=importlib.util.module_from_spec(spec)
spec.loader.exec_module(installer)

BASE_FILES={
"src/potbot/tools/agent_xpra_displays.py":'''from pathlib import Path
from uuid import UUID
class AgentXpraDisplayPool:
    def _agent(self, agent_id): return None
    def environment(self, agent_id): return {"DISPLAY": ":440"}
    def retire(self, agent_id: UUID, *, process_stopped: bool) -> None:
        pass
''',
"src/potbot/tools/xpra_app_sessions.py":'''from pathlib import Path
from typing import Any
from uuid import UUID
class XpraApplicationSupervisor:
    def agent_sessions(self, agent_id: UUID) -> list[dict[str, Any]]:
        return []
''',
"src/potbot/tools/x11_workspace_server.py":'''def create_app(apps, server):
    from potbot.domain.errors import DomainError
    @app.websocket("/v1/xpra/ws")
    async def websocket_bridge(ws):
        pass
    return app
''',
"frontend/src/lib/xpra-contract.ts":'''if (ws.pathname !== "/v1/xpra/ws") throw Error("Wrong path");
''',
"frontend/src/components/OrbWorkspace.tsx":'''import { XpraApplicationsPanel } from "./XpraApplicationsPanel";
const COMPONENTS = {
  applications: XpraApplicationsPanel, activity: ActivityPanel, xwindow: XpraWindowPanel,
};
function DockedScene() {
  const apiRef = useDockApi();
  const onReady = useCallback(({api}) => {
    const removed = api.onDidRemovePanel(panel => {
      queueMicrotask(() => {
        if (panel.id.startsWith("x11:") && XWINDOW_ID.test(panel.id.slice(4)))
          onXWindowHidden(panel.id.slice(4));
      });
    });
    const changed = api.onDidLayoutChange(() => {
      onGraphMinimized(!api.getPanel("graph"));
    });
    onGraphMinimized(!api.getPanel("graph"));
  }, [apiRef, workspace.id, onGraphMinimized, onXWindowHidden]);
}
function OrbWorkspace() {
  const workspace = workspaces[selected];
  return <WorkspaceProvider value={session}>
      <DockApiContext.Provider value={apiRef}>
      </DockApiContext.Provider>
  </WorkspaceProvider>;
}
''',
"frontend/src/components/XpraApplicationsPanel.tsx":'''import { DockControls } from "./Panels";
function XpraApplicationsPanel() {
 return <section>
    <div className="applications-search">
    </div>
 </section>;
}
'''
}


def make_checkout(path:Path, crlf=False):
    subprocess.run(["git", "init", "-q"], cwd=path, check=True)
    for relative,src in BASE_FILES.items():
        file=path/relative
        file.parent.mkdir(parents=True,exist_ok=True)
        file.write_bytes(src.replace("\n","\r\n").encode() if crlf else src.encode())


def run_installer(path, dry=False):
    return subprocess.run([sys.executable,str(ROOT/"install.py"),str(path),
                           *( ["--dry-run"] if dry else [])],capture_output=True,text=True)

@pytest.mark.parametrize("crlf",[False,True])
def test_install_dry_run_apply_repeat(tmp_path,crlf):
    make_checkout(tmp_path,crlf)
    original=(tmp_path/"src/potbot/tools/xpra_app_sessions.py").read_bytes()
    assert run_installer(tmp_path,True).returncode==0
    assert (tmp_path/"src/potbot/tools/xpra_app_sessions.py").read_bytes()==original
    result=run_installer(tmp_path)
    assert result.returncode==0,result.stderr
    now=(tmp_path/"src/potbot/tools/xpra_app_sessions.py").read_bytes()
    assert b"agent_display_inventory" in now
    assert (b"\r\n" in now)==crlf
    assert (tmp_path/"src/potbot/tools/agent_xpra_streams.py").is_file()
    assert run_installer(tmp_path, True).returncode==0
    assert run_installer(tmp_path).returncode==0
    assert (tmp_path/"src/potbot/tools/xpra_app_sessions.py").read_bytes()==now


def test_preflight_refuses_conflicting_file_without_any_writes(tmp_path):
    make_checkout(tmp_path)
    broken=tmp_path/"frontend/src/lib/xpra-contract.ts"
    broken.write_text("navigator.evil();\n")
    prior={k:(tmp_path/k).read_bytes() for k in BASE_FILES}
    result=run_installer(tmp_path)
    assert result.returncode==1
    assert all((tmp_path/k).read_bytes()==v for k,v in prior.items())
    assert not (tmp_path/"src/potbot/tools/agent_xpra_streams.py").exists()


def test_refuses_existing_modified_new_file(tmp_path):
    make_checkout(tmp_path)
    target=tmp_path/"src/potbot/tools/agent_xpra_streams.py"
    target.write_text("unsafe shadow code\n")
    assert run_installer(tmp_path).returncode==1
    assert target.read_text()=="unsafe shadow code\n"


def test_rejects_unsafe_symlink(tmp_path):
    make_checkout(tmp_path)
    path=tmp_path/"frontend/src/components/OrbWorkspace.tsx"
    path.unlink();path.symlink_to(tmp_path/"frontend/src/lib/xpra-contract.ts")
    assert run_installer(tmp_path).returncode==1


def test_dockview_layout_callback_and_initialization_are_not_ambiguous():
    original = BASE_FILES["frontend/src/components/OrbWorkspace.tsx"]
    assert original.count('    onGraphMinimized(!api.getPanel("graph"));\n') == 2
    updated = installer.patch_orb(original)
    assert updated.count('    agentHub.openActiveWindows();\n') == 1
    assert updated.count('      onGraphMinimized(!api.getPanel("graph"));\n') == 1
    assert installer.patch_orb(updated) == updated


def test_dockview_refuses_two_exact_indentation_matches():
    original = BASE_FILES["frontend/src/components/OrbWorkspace.tsx"]
    doubled = original.replace('    onGraphMinimized(!api.getPanel("graph"));\n  },',
                               '    onGraphMinimized(!api.getPanel("graph"));\n'
                               '    onGraphMinimized(!api.getPanel("graph"));\n  },')
    with pytest.raises(ValueError, match="required whole-line anchor"):
        installer.patch_orb(doubled)


def test_partial_agent_orb_install_is_not_treated_as_complete():
    original = BASE_FILES["frontend/src/components/OrbWorkspace.tsx"]
    modified = original.replace('import { XpraApplicationsPanel }',
                                'import { AgentXpraStreamHost } from "./partial";\n'
                                'import { XpraApplicationsPanel }', 1)
    with pytest.raises(ValueError, match="partial integration"):
        installer.patch_orb(modified)
