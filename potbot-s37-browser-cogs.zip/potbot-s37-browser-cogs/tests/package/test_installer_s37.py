"""Synthetic git-worktree S37 patch tests, independent of GitHub network/Xpra."""
from __future__ import annotations

import importlib.util
import subprocess
from pathlib import Path

import pytest

PKG = Path(__file__).resolve().parents[2]
SPEC = importlib.util.spec_from_file_location("potbot_s37_installer", PKG / "install.py")
assert SPEC is not None and SPEC.loader is not None
installer = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(installer)


def fake_git_worktree(tmp_path: Path) -> Path:
    folder = tmp_path / "potbot"
    folder.mkdir()
    subprocess.run(["git", "init", "-q", str(folder)], check=True)
    for name, rows in installer.REPLACEMENTS.items():
        file = folder / name
        file.parent.mkdir(parents=True, exist_ok=True)
        # All anchors occur exactly once, even when later replacements add
        # nested text and keep their original anchor inside the replacement.
        text = "\n# independent original anchor\n".join(old for old, _ in rows)
        file.write_text(text + "\n")
    return folder


def test_preflight_replay_and_conflict(tmp_path: Path):
    repo = fake_git_worktree(tmp_path)
    orig = (repo / "src/potbot/tools/xpra_browser_worker.py").read_bytes()
    assert installer.install(repo, dry_run=True)["dry_run"] is True
    assert (repo / "src/potbot/tools/xpra_browser_worker.py").read_bytes() == orig
    created = installer.install(repo)
    assert len(created["changes"]) == len(installer.REPLACEMENTS) + len(installer.ADDITIONS)
    assert installer.install(repo)["already_installed"] is True
    assert installer.install(repo, dry_run=True)["already_installed"] is True
    backup_dir = Path(subprocess.check_output([
        "git", "-C", str(repo), "rev-parse", "--absolute-git-dir"], text=True).strip()) / "potbot-backups/s37-browser-cogs"
    assert (backup_dir / "receipt.json").is_file()
    assert (backup_dir / "src__potbot__tools__xpra_browser_worker.py.bak").read_bytes() == orig
    (repo / "src/potbot/tools/xpra_browser_worker.py").write_text("# unreviewed local edit\n")
    with pytest.raises(RuntimeError):
        installer.install(repo)


def test_duplicate_or_missing_anchor_rejected_without_side_effects(tmp_path: Path):
    repo = fake_git_worktree(tmp_path)
    file = repo / "src/potbot/tools/xpra_browser_control.py"
    original = file.read_text()
    file.write_text(original + original)
    with pytest.raises(RuntimeError):
        installer.install(repo)
    assert not (repo / "src/potbot/tools/browser_cog_contracts.py").exists()


def test_new_user_file_not_overwritten(tmp_path: Path):
    repo = fake_git_worktree(tmp_path)
    existing = repo / "src/potbot/tools/browser_evidence.py"
    existing.parent.mkdir(parents=True, exist_ok=True)
    existing.write_text("custom code\n")
    with pytest.raises(RuntimeError):
        installer.install(repo)
    assert existing.read_text() == "custom code\n"
