# Potbot S37 — Browser Cogs and durable evidence

**Patch base:** `main@68d65e25f647652b4b4119495779ea8fb57e4cae` (browser control).
The separate S36 workspace-log patch can be present: S37 edits different anchors in shared Xpra code.

## Apply (existing Potbot Git worktree)

```bash
python3 /path/to/potbot-s37-browser-cogs/install.py /path/to/potbot --dry-run
python3 /path/to/potbot-s37-browser-cogs/install.py /path/to/potbot
cd /path/to/potbot
PYTHONPATH=src pytest -q tests/unit/test_browser_cogs_s37.py \
  tests/unit/test_xpra_browser_control.py tests/unit/test_xpra_browser_worker.py
PYTHONPATH=src python3 -m compileall -q src/potbot
```

The installer requires exact unique reviewed anchors, Git metadata, no
conflicting destination files and a clean install receipt. It backs up changed
originals in `.git/potbot-backups/s37-browser-cogs/`, not in the project tree.
Reruns are idempotent. An existing S37 file that has diverged is **never**
overwritten silently. Review `git diff` before committing.

## Main changes

- Install four versioned SYN Cogs: observe, act, pick, and capture, using the
  existing sealed `BoundCogRegistry` and `ExecutionCogRuntime` profile machinery.
- Operator-approved `BrowserControlService` dispatches into a previously
  admitted Xpra Chromium session, never an unconfined host browser.
- Private `BrowserEvidenceRecorder` persists observations, captured JPEGs and
  manifests via the **existing** workspace ArtifactStore with SHA-256 checks.
- Existing execution journal and CogWorkMonitor emit causal work observations
  and receipts. Screenshot bytes do not go inline into Cog output.
- Browser worker now distinguishes definite preflight rejection from an error
  after a mutating action may have taken effect. Indeterminate effects fence
  their browser instead of permitting automatic retry.
- Tests exercise effect-type separation, workspace/principal scoping,
  one-use invocation IDs, evidence-integrity checks, safe action failure, and
  source-only installer behavior.

See `docs/implementation/37-browser-cogs-and-evidence.md` for operator wiring,
qualification gates, security limitations, and next steps. This source patch is
**not** a proof of live Xpra/Bubblewrap/PostgreSQL operation.
