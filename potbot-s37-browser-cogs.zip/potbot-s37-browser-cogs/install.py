#!/usr/bin/env python3
"""S37 Potbot browser Cog/evidence patch; safe exact-anchor worktree installer.

No network, code execution or host service startup. Changes are staged and
verified before publication. Existing user edits cause a refusal, never a fuzzy
merge. Files already patched are accepted byte-for-byte (idempotent).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

BASE = "68d65e25f647652b4b4119495779ea8fb57e4cae"
REPLACEMENTS: dict[str, list[tuple[str, str]]] = {}
ADDITIONS = (
    "src/potbot/tools/browser_cog_contracts.py",
    "src/potbot/tools/browser_evidence.py",
    "src/potbot/cogs/browser.py",
    "src/potbot/controller/browser_cogs.py",
    "tests/unit/test_browser_cogs_s37.py",
    ".github/workflows/browser-cogs-s37.yml",
    "docs/implementation/37-browser-cogs-and-evidence.md",
)


def patch(path: str, previous: str, replacement: str) -> None:
    if not previous or previous == replacement:
        raise ValueError("invalid source patch")
    REPLACEMENTS.setdefault(path, []).append((previous, replacement))


# An *actual* failed action can still have performed side effects before the
# Playwright call raised. Mark only pre-validation rejections definite.
patch("src/potbot/tools/xpra_browser_worker.py",
      'ALLOWED_ROLES = frozenset({"button", "link", "textbox", "checkbox", "radio", "combobox", "option", "menuitem", "tab", "switch", "searchbox"})\n',
      'ALLOWED_ROLES = frozenset({"button", "link", "textbox", "checkbox", "radio", "combobox", "option", "menuitem", "tab", "switch", "searchbox"})\n'
      '\n\ndef browser_operation_may_mutate(command: object) -> bool:\n'
      '    """Execution-failure outcomes for mutations must be fenced, not retried."""\n'
      '    return isinstance(command, dict) and (command.get("op") in {\n'
      '        "navigate", "input.pointer", "input.keyboard", "role.click",\n'
      '        "role.fill", "inspect.start", "inspect.stop",\n'
      '    } or (command.get("op") == "cdp" and command.get("method") in CDP_INPUT))\n')
patch("src/potbot/tools/xpra_browser_worker.py",
      '            ident: Any = None\n            try:\n                request = json.loads(line)\n',
      '            ident: Any = None\n            command: dict[str, Any] | None = None\n            try:\n                request = json.loads(line)\n')
patch("src/potbot/tools/xpra_browser_worker.py",
      '                response = {"id": ident, "ok": False, "error": "browser command was rejected or failed"}\n',
      '                response = {"id": ident, "ok": False, "error": "browser command was rejected or failed",\n'
      '                            "indeterminate": browser_operation_may_mutate(command)}\n')
patch("src/potbot/tools/xpra_browser_worker.py",
      '                encoded = json.dumps({"id": ident, "ok": False, "error": "browser response exceeded size limit"})\n',
      '                encoded = json.dumps({"id": ident, "ok": False,\n'
      '                                      "error": "browser response exceeded size limit",\n'
      '                                      "indeterminate": browser_operation_may_mutate(command)})\n')
patch("src/potbot/tools/xpra_browser_control.py",
      'from potbot.tools.xpra_browser_worker import validate_command\n',
      'from potbot.tools.xpra_browser_worker import browser_operation_may_mutate, validate_command\n')
patch("src/potbot/tools/xpra_browser_control.py",
      '                        if not data["ok"]:\n                            raise InvalidInputError("browser command was rejected or failed")\n',
      '                        if not data["ok"]:\n'
      '                            # Older rootfs workers may not report an\n'
      '                            # indeterminate flag. Mutation is STILL uncertain.\n'
      '                            if browser_operation_may_mutate(approved) or data.get("indeterminate") is True:\n'
      '                                raise TimeoutError("browser action outcome is indeterminate")\n'
      '                            raise InvalidInputError("browser command was rejected or failed")\n')
patch("src/potbot/tools/xpra_app_sessions.py",
      '    def detach(self, identifier: str) -> dict[str, Any]:\n',
      '    def fence_browser(self, identifier: str) -> None:\n'
      '        """Host-only; force terminate a possibly effected browser command."""\n'
      '        with self._lock:\n'
      '            app = self._get(identifier)\n'
      '            if app.recipe.kind != "controlled-browser":\n'
      '                raise ScopeDeniedError("only browser sessions may be fenced")\n'
      '            app.indeterminate = True\n'
      '            self._terminate(app)\n'
      '            self._settle()\n\n'
      '    def detach(self, identifier: str) -> dict[str, Any]:\n')

# The browser worker is COPIED into a digest-pinned rootfs at image-build
# time. Rebuild/requalify the image when this worker's failure semantics change.
patch(".github/workflows/sandbox-system-image.yml",
      '  push:\n    branches: [main]\n    paths:\n      - sandbox/**\n',
      '  push:\n    branches: [main]\n    paths:\n      - src/potbot/tools/xpra_browser_worker.py\n      - sandbox/**\n')
patch(".github/workflows/sandbox-system-image.yml",
      '  pull_request:\n    paths:\n      - sandbox/**\n',
      '  pull_request:\n    paths:\n      - src/potbot/tools/xpra_browser_worker.py\n      - sandbox/**\n')

# New exact installed profile instead of widening the existing sealed catalog.
P = "src/potbot/cogs/registry.py"
patch(P, '    artifact_upload_profile: bool = False\n',
      '    artifact_upload_profile: bool = False\n    browser_profile: bool = False\n')
patch(P, '    def installed(self) -> tuple[CogSignature, ...]:\n        if self.artifact_upload_profile:\n',
      '    def installed(self) -> tuple[CogSignature, ...]:\n'
      '        if self.browser_profile:\n'
      '            from potbot.cogs.browser import BROWSER_COGS\n'
      '            from potbot.cogs.execution import EXECUTION_COGS\n'
      '            return (*INSTALLED_COGS, *EXECUTION_COGS, *BROWSER_COGS)\n'
      '        if self.artifact_upload_profile:\n')
patch(P, '    def __post_init__(self) -> None:\n        from potbot.cogs.artifact_ranges import artifact_range_snapshot\n',
      '    def __post_init__(self) -> None:\n        from potbot.cogs.browser import browser_cog_snapshot\n'
      '        from potbot.cogs.artifact_ranges import artifact_range_snapshot\n')
patch(P, '                    self.artifact_upload_profile,\n',
      '                    self.artifact_upload_profile,\n                    self.browser_profile,\n')
patch(P, '        expected = (\n            artifact_upload_snapshot()\n',
      '        expected = (\n            browser_cog_snapshot()\n            if self.browser_profile\n            else artifact_upload_snapshot()\n')
patch(P, '    @classmethod\n    def artifact_ranges(cls) -> BoundCogRegistry:\n',
      '    @classmethod\n    def browser(cls) -> BoundCogRegistry:\n'
      '        from potbot.cogs.browser import browser_cog_snapshot\n'
      '        return cls(browser_cog_snapshot(), browser_profile=True)\n\n'
      '    @classmethod\n    def artifact_ranges(cls) -> BoundCogRegistry:\n')
patch(P, '        if self.artifact_upload_profile and isinstance(controller, ExecutionCogRuntime):\n',
      '        if self.browser_profile and isinstance(controller, ExecutionCogRuntime):\n'
      '            from potbot.cogs.browser import BROWSER_COGS\n'
      '            selected = next(\n'
      '                (s for s in (*EXECUTION_COGS, *BROWSER_COGS) if str(s.cog_ref) == cog_ref),\n'
      '                None,\n'
      '            )\n'
      '        elif self.artifact_upload_profile and isinstance(controller, ExecutionCogRuntime):\n')

E = "src/potbot/controller/execution_cogs.py"
patch(E, '        artifact_uploads: Any = None,\n        sandbox_executor: SandboxedCogExecutor | None = None,\n',
      '        artifact_uploads: Any = None,\n        browser_service: Any = None,\n'
      '        sandbox_executor: SandboxedCogExecutor | None = None,\n')
patch(E, '        if artifact_uploads is not None and artifact_ranges is None:\n',
      '        if browser_service is not None and (artifact_ranges is not None or artifact_uploads is not None):\n'
      '            raise ScopeDeniedError("Browser and artifact profiles need distinct sealed catalogues")\n'
      '        if artifact_uploads is not None and artifact_ranges is None:\n')
patch(E, '        else:\n            self.registry = BoundCogRegistry.provenance()\n',
      '        elif browser_service is not None:\n'
      '            from potbot.cogs.browser import browser_ember_bundle, installed_operations as browser_operations\n'
      '            from potbot.controller.browser_cogs import BrowserControlService\n'
      '            if (not isinstance(browser_service, BrowserControlService)\n'
      '                    or browser_service.actor != actor or browser_service.policy != policy\n'
      '                    or browser_service.artifacts is not artifacts):\n'
      '                raise ScopeDeniedError("browser service differs from the pinned controller scope")\n'
      '            self.registry = BoundCogRegistry.browser()\n'
      '            ember_bundle = browser_ember_bundle\n'
      '            self._direct_operations = browser_operations(browser_service, policy)\n'
      '        else:\n            self.registry = BoundCogRegistry.provenance()\n')


def _git_dir(repo: Path) -> Path:
    cp = subprocess.run(["git", "-C", str(repo), "rev-parse", "--absolute-git-dir"],
                        text=True, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                        check=False)
    if cp.returncode != 0:
        raise RuntimeError("destination must be an existing Git worktree")
    location = Path(cp.stdout.strip())
    if not location.is_dir():
        raise RuntimeError("Git metadata directory is unavailable")
    return location


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _marker_path(git: Path) -> Path:
    return git / "potbot-backups" / "s37-browser-cogs" / "receipt.json"


def _manifest(additions: dict[str, bytes], originals: dict[str, bytes],
              modifications: dict[str, bytes]) -> dict[str, object]:
    return {"schema": "potbot-s37-browser-cogs-install/v1", "base_commit": BASE,
            "files": {k: {"original": _sha(originals[k]) if k in originals else None,
                          "installed": _sha(data)}
                      for k, data in sorted({**modifications, **additions}.items())}}


def install(target: Path, *, dry_run: bool = False) -> dict[str, object]:
    target = target.resolve(strict=True)
    git = _git_dir(target)
    source = Path(__file__).resolve().parent
    additions: dict[str, bytes] = {}
    for name in ADDITIONS:
        path = source / name
        if path.is_symlink() or not path.is_file():
            raise RuntimeError("S37 package is missing a required source file")
        additions[name] = path.read_bytes()
    paths = sorted(set(ADDITIONS) | set(REPLACEMENTS))
    mark = _marker_path(git)
    prior = json.loads(mark.read_text(encoding="utf-8")) if mark.exists() else None
    if prior is not None and (prior.get("schema") != "potbot-s37-browser-cogs-install/v1"
                              or set(prior.get("files", {})) != set(paths)):
        raise RuntimeError("S37 installation receipt is invalid or incomplete")
    originals: dict[str, bytes] = {}
    modifications: dict[str, bytes] = {}
    staged: dict[str, bytes] = {}
    for name in paths:
        out = target / name
        if out.is_symlink() or any(parent.is_symlink() for parent in out.parents if parent != target and target in parent.parents):
            raise RuntimeError(f"S37 target has a redirected parent: {name}")
        if name in ADDITIONS:
            expected = additions[name]
            if out.exists() and out.read_bytes() != expected:
                raise RuntimeError(f"S37 refuses to overwrite existing file: {name}")
            if not out.exists():
                staged[name] = expected
            continue
        if not out.is_file():
            raise RuntimeError(f"S37 target file is missing: {name}")
        original = out.read_bytes()
        try:
            transformed = original.decode("utf-8")
        except UnicodeError as exc:
            raise RuntimeError("S37 expected UTF-8 source files") from exc
        was_patched = True
        for old, new in REPLACEMENTS[name]:
            old_count, new_count = transformed.count(old), transformed.count(new)
            if new_count == 1:
                continue
            elif old_count == 1:
                transformed = transformed.replace(old, new, 1)
                was_patched = False
            else:
                raise RuntimeError(f"S37 ambiguous or divergent source anchor in {name}")
        replacement = transformed.encode("utf-8")
        if replacement != original:
            staged[name] = replacement
            originals[name] = original
        modifications[name] = replacement
    expected_manifest = _manifest(additions, originals, modifications)
    if prior is not None:
        for name in paths:
            if prior["files"][name]["installed"] != expected_manifest["files"][name]["installed"]:
                raise RuntimeError("S37 installed file was modified since previous apply")
    if dry_run:
        return {"dry_run": True, "changes": sorted(staged), "already_installed": not staged}
    if prior is not None and not staged:
        return {"dry_run": False, "changes": [], "already_installed": True,
                "receipt_sha256": _sha(mark.read_bytes())}
    backups = git / "potbot-backups" / "s37-browser-cogs"
    backups.mkdir(mode=0o700, parents=True, exist_ok=True)
    if prior is not None and staged:
        raise RuntimeError("S37 installed files have been removed; reconcile before replay")
    # Stage originals before the first mutation. Failed interrupted staging is
    # recoverable from these backups, never an invitation to overwrite edits.
    for name, data in originals.items():
        dest = backups / (name.replace("/", "__") + ".bak")
        if dest.exists() and dest.read_bytes() != data:
            raise RuntimeError(f"S37 original backup has changed: {name}")
        if not dest.exists():
            with dest.open("xb") as handle:
                handle.write(data)
                handle.flush()
                os.fsync(handle.fileno())
    # Atomic file replacement for all already existing files. Failure between
    # files is not falsely called a completed patch; exact anchors permit safe
    # reconciliation on the next run (but the user should inspect git diff).
    for name, data in staged.items():
        dest = target / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        mode = dest.stat().st_mode & 0o777 if dest.exists() else 0o644
        temp = dest.with_name(dest.name + ".s37-install-tmp")
        if temp.exists():
            raise RuntimeError(f"S37 temporary file needs reconciliation: {name}")
        try:
            fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, mode)
            with os.fdopen(fd, "wb") as output:
                output.write(data)
                output.flush()
                os.fsync(output.fileno())
            temp.replace(dest)
        finally:
            temp.unlink(missing_ok=True)
    mark.write_text(json.dumps(expected_manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return {"dry_run": False, "changes": sorted(staged), "already_installed": not staged,
            "receipt_sha256": _sha(mark.read_bytes())}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("worktree", type=Path)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    try:
        print(json.dumps(install(args.worktree, dry_run=args.dry_run), sort_keys=True, indent=2))
        return 0
    except (OSError, RuntimeError, ValueError, KeyError, TypeError) as error:
        print(f"S37 refused installation: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
