# S40 — Agent-private Xpra display boundary

## State of delivery

S40 builds on the merged S39 Potbot repository (`13f9b599a39da8e151106f680709de1c37f83061`). It adds a **host-only, opt-in** private Xpra/Xdummy server for each registered agent that needs a `controlled-browser` session. Existing Xpra workspace GUI applications and their native per-window HTML5 display stream remain unchanged.

The source-only unit tests are **not** a proof of deployed kernel isolation. Qualified Linux/WSL2, real Xpra/Xdummy, bubblewrap, libseccomp, a correctly pinned image, live worker monitoring and cross-agent tests are required on the target host. S39's strict workspace-wide Xpra input policy continues to apply for the legacy operator display.

## Why a new display per agent

X11 authentication grants access to an **entire display**, not a single application window. Read-only Xpra denies input arriving from the Xpra HTML5 client, but cannot prevent another guest process possessing the X socket/cookie from sending native X11 requests. Logical process reservations alone cannot solve that issue. S40 keeps every agent browser on an independent operator-started Xpra/Xdummy server with a different physical `XNNN` socket and Xauthority cookie.

```text
Workspace operator (outside shared /home)
├─ main Xpra display              existing operator GUI, strict-input optional
├─ private-root/<agent-A-UUID>/   Xpra #A, unique X socket and secret
│    └─ qualified agent-A bwrap   only /home/agent-A mounted, own X socket
└─ private-root/<agent-B-UUID>/   Xpra #B, unique X socket and secret
     └─ qualified agent-B bwrap   only /home/agent-B mounted, own X socket

Each controlled Chromium worker: Playwright/Patchright ↔ private X11 server
     │           existing typed browser RPC and agent reservation
     └─ screenshot/ARIA/DOM evidence → private Potbot ArtifactStore and gallery
```

## Boundary and launch admission

`AgentXpraDisplayPool` may only be created by the trusted host controller, using an enrolled `AgentHomeRegistry`, current `WorkspaceLeaseLedger`, and an independently pinned `SharedWorkspaceRuntime` and qualified `SharedWorkspaceBubblewrapBackend`. The pool root is a *real*, mode `0700`, host-UID-owned directory **outside** `/home`, rootfs, model staging, shared tools/models and AI configuration/history mounts. Each agent's own subfolder is a private Xpra server root. Abandoned or stale Xpra session state remains a hard failure.

The agent's bwrap command is derived from the normal qualified launch and then narrowed. **No arbitrary mount inputs are accepted.** It replaces the broad `--bind <workspace home> /home` with a private `/home` tmpfs, one bind for `/home/<registered-agent>` and a separate tmpfs-backed `/home/.tmp`. The only X11 Unix socket visible is the per-agent display socket. An Xauthority cookie from the host-private server is copied into a sealed memfd and mounted read-only at `/home/.tmp/potbot-agent-Xauthority`. The cookie never appears in a public argument, HTTP response, workspace-home file, agent prompt or source checkout.

Shared model staging is hidden behind a private tmpfs and the AI configuration mount is downgraded to read-only for browsers. Shared tools remain read-only and `--unshare-all`/seccomp still forbids AF_INET and AF_INET6. The optional S39 HTTPS broker is bound into that *one agent's* private namespace using its existing Unix-socket/descriptor capability and exact-host policy, without direct TCP fallback. The agent-private Xpra server always starts `readonly_mode=True`: all GUI input uses the authenticated Playwright/CDP RPC under an agent-owned `BrowserSessionCoordinator` reservation.

An agent launch is available **only to trusted host code**:

```python
session = supervisor.start("controlled-browser", agent_id=registered_agent_id)
lease = supervisor.agent_browser_reservation(registered_agent_id, session["id"])
result = supervisor.browser_command(
    session["id"], {"op": "accessibility"},
    lease_token=lease["token"], actor_agent_id=registered_agent_id,
)
```

No HTTP route accepts an `agent_id` or exposes the host's agent reservation token. The `BrowserControlService` passes its already admitted reservation's agent UUID back into the supervisor for verification. A foreign agent UUID, foreign browser session, UI caller or expired/fenced lease is denied. The public inventory identifies agent sessions as `agent-browser` so the operator inspector does not accidentally offer to reserve them as legacy workspace browsers.

### Optional private display configuration

Add a trusted **operator-only** block alongside the existing approved Xpra policy fields. This is a **fragment** (retain all mandatory fields, the approved recipes and current image pin):

```json
{
  "browserLeases": true,
  "strictXpraInput": true,
  "agentDisplays": {
    "root": "/var/lib/potbot/operators/private-xpra/my-workspace",
    "workspaceName": "my-workspace",
    "maxDisplays": 4
  }
}
```

Create the `root` directory in advance with owner equal to the Xpra operator service UID, mode `0700`. Its `workspaceName` must resolve to the **same** already registered agent-workspace group; it does not enroll agents. The public Xpra application endpoint still accepts only `{"kind":"..."}` and uses the legacy operator branch, not an agent-controlled launch. S36 log monitoring, if deployed, remains mandatory for the selected image; this patch does not weaken its watcher.

## Process monitoring and recovery

`AgentXpraSandboxBackend` subclasses the installed `SharedWorkspaceBubblewrapBackend` purely as a scoped supervisor adapter. It delegates the *same* qualified launch preparation to the agent-private pool, and `ProcessSupervisor` retains the existing process tree, file/syscall monitoring and resource receipt flow. It does not grant a new executable or installation permission.

Only **one live browser per agent** is admitted by the Xpra application supervisor. Agent displays are not reused across agents, and cannot be retired until the entire owned browser process is confirmed stopped. A failed/disconnected browser command is fenced; an expired lease cannot be stolen by another agent. A crash or lost private display cancels the supervised application group conservatively. Private Xpra display failure does not create an unsandboxed fallback.

## Host acceptance — mandatory before enabling on real agents

Run the qualified image with two **distinct enrolled agents**. A deliberately opt-in real-host harness is provided in `tests/acceptance/xpra_agent_isolation_s40.py`; it launches two real Xpra servers and uses the actual `ProcessSupervisor` (not a fake). It must independently confirm process-tree shutdown and live isolation identities. It checks that each guest sees its own cookie and X socket, that the peer's `/home` is absent, that the operator's workspace-wide Xauthority isn't visible, that AF_INET is blocked and that the private network namespace differs from the host. A failed test is a deployment blocker.

The harness needs a pinned signed OCI image, registered agent homes, a separately configured telemetry system and `--operator-root`. For example, after `uv sync --locked --extra web --dev`:

```bash
PYTHONPATH=src uv run --locked python tests/acceptance/xpra_agent_isolation_s40.py \
  --workspace-id "$WORKSPACE_ID" --principal-id "$PRINCIPAL_ID" \
  --agent-a "$AGENT_A" --agent-b "$AGENT_B" --workspace-name "$WORKSPACE_NAME" \
  --rootfs "$ROOTFS" --home "$WORKSPACE_HOME" \
  --model-staging "$STAGING" --shared-models "$SHARED_MODELS" \
  --shared-tools "$SHARED_TOOLS" --ledger "$LEDGER" \
  --operator-root "$OPERATOR_PRIVATE_XPRA" \
  --image-digest "$IMAGE_DIGEST" --qualification-sha256 "$QUALIFICATION_SHA" \
  --report "$HOST_PRIVATE_REPORT"
```

Where modern images enable `/etc/ai`, also supply `--ai-config` and `--ai-past`; the host watcher and any S36 log operator must already be qualified. Test the proxy separately against a real certificate/hostname failure and a foreign agent mount namespace. **No single smoke test is full hostile-agent qualification.** Failure to inspect kernel isolation identities or process-tree termination counts as failure, never a skip.

## Remaining S41 work

The Potbot UI still has **one** workspace-wide Xpra HTML5 stream. S40 intentionally does *not* multiplex agent-private Xpra frames into that operator stream or pretend its existing `xwin-...` window IDs are globally unique. Agents use the secure browser RPC and its screenshot/ARIA evidence gallery meanwhile. S41 should implement session-scoped Xpra tickets, per-stream window namespaces and Dockview per-agent viewers, preserving readonly input and full audit/readback. Stronger system-wide per-agent DAC/idmapped filesystem isolation is still a separate OS host qualification item.
