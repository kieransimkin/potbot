"""Host reservation identity and private-browser frontend nonexposure tests."""
from __future__ import annotations

import threading
from types import SimpleNamespace
from uuid import uuid4

import pytest

from potbot.domain.errors import CapabilityUnavailableError, ScopeDeniedError, StateMismatchError
from potbot.tools.browser_session_leases import BrowserSessionCoordinator
from potbot.tools.xpra_app_sessions import XpraApplicationSupervisor, _App, AppRecipe


class Process:
    pid = 99999998
    def poll(self): return None


class Channel:
    def __init__(self): self.calls = []
    def call(self, payload):
        self.calls.append(payload)
        return {"aria": "- button: Save"}


def supervisor():
    workspace, principal, agent = uuid4(), uuid4(), uuid4()
    app = _App('a'*32, AppRecipe('controlled-browser', 'Browser', ('/bin/true',)), Process(), 'pin')
    app.agent_id = agent
    app.browser_control = Channel()
    service = object.__new__(XpraApplicationSupervisor)
    service.workspace_id, service.principal_id = workspace, principal
    service._lock = threading.RLock()
    service._guard = SimpleNamespace(fenced=False)
    service._apps = {app.id: app}
    service.browser_leases = BrowserSessionCoordinator(workspace, principal)
    service.agent_displays = SimpleNamespace(environment=lambda _: {'DISPLAY': ':472'})
    return service, app, agent


def test_agent_browser_cannot_be_leased_through_public_operator_path():
    service, app, agent = supervisor()
    assert app.view().document()['kind'] == 'agent-browser'
    with pytest.raises(CapabilityUnavailableError):
        service.browser_reservation(app.id, 'acquire')
    reservation = service.agent_browser_reservation(agent, app.id)['token']
    with pytest.raises(ScopeDeniedError):
        service.browser_command(app.id, {'op': 'accessibility'}, lease_token=reservation)
    with pytest.raises(ScopeDeniedError):
        service.browser_command(app.id, {'op': 'accessibility'}, lease_token=reservation,
                                actor_agent_id=uuid4())
    assert service.browser_command(app.id, {'op': 'accessibility'}, lease_token=reservation,
                                   actor_agent_id=agent)['aria'].startswith('- button')
    assert len(app.browser_control.calls) == 1
    service.agent_browser_reservation(agent, app.id, action='release', token=reservation)
    with pytest.raises(ScopeDeniedError):
        service.browser_command(app.id, {'op': 'state'}, lease_token=reservation, actor_agent_id=agent)


def test_agent_reservation_cannot_cross_session_identity():
    service, app, agent = supervisor()
    other = _App('b'*32, app.recipe, Process(), 'pin')
    other.agent_id = uuid4()
    other.browser_control = Channel()
    service._apps[other.id] = other
    ticket = service.agent_browser_reservation(agent, app.id)['token']
    with pytest.raises(ScopeDeniedError):
        service.browser_command(other.id, {'op': 'state'}, lease_token=ticket,
                                actor_agent_id=other.agent_id)
    assert not other.browser_control.calls


def test_agent_reservation_is_not_replayed_after_fence():
    service, app, agent = supervisor()
    token = service.agent_browser_reservation(agent, app.id)['token']
    service.browser_leases.fence(app.id)
    service._terminate = lambda _app: None
    service._settle = lambda: None
    with pytest.raises(StateMismatchError):
        service.browser_command(app.id, {'op': 'state'}, lease_token=token, actor_agent_id=agent)
