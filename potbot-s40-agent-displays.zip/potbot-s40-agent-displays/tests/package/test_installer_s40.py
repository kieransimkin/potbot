"""Offline S40 installer tests; synthetic S39 fixtures, never modify user trees."""
from __future__ import annotations

import ast
import importlib.util
import subprocess
from pathlib import Path

import pytest

BUNDLE = Path(__file__).resolve().parents[2]


def load(name: str, path: Path):
    import sys
    sys.path.insert(0, str(BUNDLE))
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def baseline_texts() -> dict[str, str]:
    # The transform's approved *old* fragments provide a deterministic test
    # fixture without reading or copying any user repository files.
    tree = ast.parse((BUNDLE / "_rules.py").read_text())
    assignments = [n for n in ast.walk(tree) if isinstance(n, ast.Assign) and
                   len(n.targets) == 1 and isinstance(n.targets[0], ast.Name) and
                   n.targets[0].id == "edits"]
    assert len(assignments) == 1
    app = "\n# isolated anchor\n".join(pair[0] for pair in ast.literal_eval(assignments[0].value))
    app += '\n        optional = {"browserLeases", "strictXpraInput", "browserEgress"}\n'
    cogs = '                raw = self.apps.browser_command(session, cmd, lease_token=reserved.token)\n'
    policy = '    if "browserEgress" in raw and (not strict or not isinstance(raw["browserEgress"], dict)):\n'
    return {"src/potbot/tools/xpra_app_sessions.py": app,
            "src/potbot/controller/browser_cogs.py": cogs,
            "src/potbot/tools/browser_operator_policy.py": policy}


def fixture(tmp_path: Path, *, newline: str = "\n", s36: bool = False) -> Path:
    subprocess.run(["git", "init", "-q", str(tmp_path)], check=True)
    for req in ("src/potbot/tools/browser_session_leases.py",
                "src/potbot/tools/browser_connect_gateway.py",
                ".github/workflows/browser-s39.yml"):
        p = tmp_path / req
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text("# fixture\n")
    for rel, original in baseline_texts().items():
        if s36 and rel.endswith('xpra_app_sessions.py'):
            original = original.replace('"browserEgress"}', '"browserEgress", "logs"}')
        p = tmp_path / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(original.replace("\n", newline).encode())
    return tmp_path


def test_installer_applies_once_and_preserves_reapply(tmp_path: Path):
    installer = load("s40_install", BUNDLE / "install.py")
    repo = fixture(tmp_path)
    first = installer.planned_changes(repo)
    assert len(first) == len(installer.MODIFIED) + len(installer.NEW)
    installer.install(repo, first)
    assert installer.planned_changes(repo) == {}
    for rel in installer.MODIFIED:
        assert "agent" in (repo / rel).read_text()
    backup = repo / ".git" / "potbot-patches" / "s40-agent-xpra"
    assert any(backup.rglob("*.original"))


def test_crlf_and_s36_operator_allowlist_variant(tmp_path: Path):
    installer = load("s40_install_crlf", BUNDLE / "install.py")
    repo = fixture(tmp_path, newline="\r\n", s36=True)
    changes = installer.planned_changes(repo)
    installer.install(repo, changes)
    path = repo / "src/potbot/tools/xpra_app_sessions.py"
    text = path.read_bytes()
    assert b"\r\n" in text and b'"logs", "agentDisplays"' in text
    assert installer.planned_changes(repo) == {}


def test_unknown_drift_is_refused(tmp_path: Path):
    installer = load("s40_install_drift", BUNDLE / "install.py")
    repo = fixture(tmp_path)
    target = repo / "src/potbot/tools/xpra_app_sessions.py"
    target.write_text(target.read_text().replace('self.browser_leases = browser_leases',
                                                    'self.browser_leases = attacker_lease'))
    with pytest.raises(ValueError, match="divergent"):
        installer.planned_changes(repo)
    assert not (repo / "src/potbot/tools/agent_xpra_displays.py").exists()


def test_symlinks_in_new_destination_are_rejected(tmp_path: Path):
    installer = load("s40_install_symlink", BUNDLE / "install.py")
    repo = fixture(tmp_path)
    target = repo / "src/potbot/tools/agent_xpra_displays.py"
    target.symlink_to(repo / "src/potbot/tools/xpra_app_sessions.py")
    with pytest.raises(ValueError, match="symlink"):
        installer.planned_changes(repo)
