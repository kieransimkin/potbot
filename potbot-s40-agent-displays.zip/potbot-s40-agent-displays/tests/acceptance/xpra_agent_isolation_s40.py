#!/usr/bin/env python3
"""Opt-in *real host* S40 isolated Xpra/X11 + seccomp acceptance.

This is not a mock or a source-only verification. Requires native Linux/WSL2,
Xpra/Xdummy, xauth, qualified rootfs, bwrap, strace/cgroup telemetry and two
previously enrolled agents. Failure to launch any prerequisite is a FAIL.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
from contextlib import nullcontext
from pathlib import Path
from uuid import UUID

from potbot.tools.agent_homes import AgentHomeRegistry
from potbot.tools.agent_xpra_displays import AgentXpraDisplayPool, AgentXpraSandboxBackend
from potbot.tools.ai_config_history import AiConfigHistoryMonitor
from potbot.tools.shared_workspace_isolation import SharedWorkspaceRuntime, SharedWorkspaceBubblewrapBackend
from potbot.tools.supervisor import ProcessRequest, ProcessSupervisor
from potbot.tools.workspace_concurrency import WorkspaceLeaseLedger


def child_script(other: str, host_netns: str) -> str:
    # Script is operator-written, never a model-provided command. Untrusted
    # host file paths and tokens are deliberately not passed to the guest.
    return '''import errno, json, os, socket
from pathlib import Path
assert Path("/home/" + %r).exists() is False
assert Path("/home/.potbot/x11/Xauthority").exists() is False
assert Path("/home/.tmp/potbot-agent-Xauthority").is_file()
assert len(Path(os.environ["XAUTHORITY"]).read_bytes()) >= 1
assert os.readlink("/proc/self/ns/net") != %r
s=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)
try:
    s.connect("/tmp/.X11-unix/X" + os.environ["DISPLAY"].split(":")[-1])
finally:
    s.close()
try:
    s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
except OSError as error:
    assert error.errno == errno.EPERM, error
else:
    s.close()
    raise AssertionError("browser opened AF_INET from sandbox")
assert Path("/var/ai").is_mount()
print(json.dumps({"home": os.environ["HOME"], "network_isolated":True,
                  "cookie_mounted":True, "x11_socket_connectable":True,
                  "shared_home_hidden":True}))
''' % (other, host_netns)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("workspace-id", "principal-id", "agent-a", "agent-b"):
        parser.add_argument("--" + name, required=True, type=UUID)
    for name in ("rootfs", "home", "model-staging", "shared-models", "shared-tools",
                 "ledger", "operator-root", "report"):
        parser.add_argument("--" + name, required=True, type=Path)
    parser.add_argument("--workspace-name", required=True)
    parser.add_argument("--image-digest", required=True)
    parser.add_argument("--qualification-sha256", required=True)
    parser.add_argument("--ai-config", type=Path)
    parser.add_argument("--ai-past", type=Path)
    args = parser.parse_args()
    if (args.ai_config is None) != (args.ai_past is None):
        parser.error("AI config/history options are a pair")
    if args.agent_a == args.agent_b:
        parser.error("two DISTINCT enrolled agents are required")
    runtime = SharedWorkspaceRuntime(
        args.image_digest, args.rootfs, args.home, args.qualification_sha256,
        model_staging=args.model_staging, shared_models=args.shared_models,
        shared_tools=args.shared_tools,
        ai_config_dir=args.ai_config, ai_history_dir=args.ai_past,
    )
    ledger = WorkspaceLeaseLedger(args.ledger, workspace_home=args.home)
    homes = AgentHomeRegistry(ledger, workspace_name=args.workspace_name)
    host_netns = os.readlink("/proc/self/ns/net")
    results = []
    confirmed_stopped = True
    manager = (AiConfigHistoryMonitor(config_dir=args.ai_config, past_dir=args.ai_past)
               if args.ai_config is not None else None)
    if manager is not None:
        manager.start()
    try:
        backend = SharedWorkspaceBubblewrapBackend(runtime, ai_monitor=manager)
        pool = AgentXpraDisplayPool(
            workspace_id=args.workspace_id, principal_id=args.principal_id,
            operator_root=args.operator_root, runtime=runtime, ledger=ledger,
            homes=homes, backend=backend, maximum=2)
        try:
            servers = [pool.acquire(agent) for agent in (args.agent_a, args.agent_b)]
            if servers[0].display == servers[1].display or (
                servers[0].server.socket_path == servers[1].server.socket_path
            ):
                raise RuntimeError("agents received the same X server")
            for agent_id, other in ((args.agent_a, args.agent_b),
                                    (args.agent_b, args.agent_a)):
                own = homes.lookup(args.workspace_id, agent_id)
                peer = homes.lookup(args.workspace_id, other)
                if own is None or peer is None:
                    raise RuntimeError("host agent registration disappeared")
                guest_backend = AgentXpraSandboxBackend(pool, agent_id)
                supervisor = ProcessSupervisor(guest_backend)
                request = ProcessRequest(
                    argv=("/usr/bin/python3", "-c", child_script(peer.directory, host_netns)),
                    workspace_root=args.home, sandbox_root=args.home,
                    cwd=args.home / own.directory, guest_uid=own.uid, guest_gid=own.gid,
                    telemetry_workspace_id=args.workspace_id, telemetry_agent_id=agent_id,
                    telemetry_identity_kind="agent", timeout_ms=15000,
                    max_output_bytes=8192, memory_bytes=2 * 1024**3, cpu_seconds=15,
                    max_file_bytes=128 * 1024**2, max_open_files=256,
                )
                result = supervisor.run(request)
                success = (result.dispatched and result.processes_stopped
                           and result.outcome == "completed" and result.exit_code == 0
                           and result.isolation_identity is not None)
                confirmed_stopped &= result.processes_stopped
                results.append({
                    "agent": str(agent_id), "passed": success,
                    "dispatched": result.dispatched, "stopped": result.processes_stopped,
                    "outcome": result.outcome, "exit_code": result.exit_code,
                    "isolation_identity": result.isolation_identity,
                    "stdout_sha256": hashlib.sha256(result.stdout).hexdigest(),
                })
                if not success:
                    raise RuntimeError("agent isolated Xpra guest did not meet real acceptance gates")
            if (args.model_staging / "probe").exists():
                raise RuntimeError("guest model-stage tmpfs leaked writes onto host")
        finally:
            # Preserve the display if an unconfirmed child may still hold the
            # X11 socket. Operator reconciliation must stop it first.
            if confirmed_stopped:
                pool.stop_all()
    finally:
        if manager is not None:
            manager.stop()
    report = {"schema": "potbot-agent-xpra-host-acceptance/v1",
              "workspace_id": str(args.workspace_id), "image_digest": args.image_digest,
              "host": platform.platform(), "qualified": len(results) == 2 and all(x["passed"] for x in results),
              "results": results, "warning": "Host smoke; not a comprehensive Xorg security proof"}
    report["sha256"] = hashlib.sha256(json.dumps(report, sort_keys=True).encode()).hexdigest()
    out = args.report.resolve()
    if out.is_relative_to(args.home.resolve()) or out.is_relative_to(args.rootfs.resolve()):
        raise RuntimeError("attestation report must be outside the guest")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, sort_keys=True, indent=2) + "\n")
    print(json.dumps({"qualified": report["qualified"], "sha256": report["sha256"]}))
    return 0 if report["qualified"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
