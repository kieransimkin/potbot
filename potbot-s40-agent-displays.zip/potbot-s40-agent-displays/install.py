#!/usr/bin/env python3
"""S40 private agent Xpra display worktree installer.

Anchored and fail-closed: old code is not overwritten unless it matches a
reviewed S39 source contract. --dry-run never writes. Edits are staged and
backed up under Git private metadata, preserving Windows CRLF where present.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import stat
import subprocess
import sys
from pathlib import Path

from _rules import transform

PACKAGE = Path(__file__).resolve().parent
MODIFIED = (
    "src/potbot/tools/xpra_app_sessions.py",
    "src/potbot/controller/browser_cogs.py",
    "src/potbot/tools/browser_operator_policy.py",
)
NEW = (
    "src/potbot/tools/agent_xpra_displays.py",
    "tests/unit/test_agent_xpra_displays_s40.py",
    "tests/unit/test_agent_xpra_supervisor_s40.py",
    "tests/acceptance/xpra_agent_isolation_s40.py",
    ".github/workflows/browser-s40.yml",
    "docs/implementation/41-s40-agent-xpra-isolation.md",
)
REQUIRED = (
    "src/potbot/tools/browser_session_leases.py",
    "src/potbot/tools/browser_connect_gateway.py",
    ".github/workflows/browser-s39.yml",
)


def checked(repo: Path, rel: str) -> Path:
    if (rel.startswith("/") or "\\" in rel or not rel
            or any(p in ("", ".", "..") for p in rel.split("/"))):
        raise ValueError("S40 path is not a safe relative repository path")
    path = repo
    for part in rel.split("/"):
        path = path / part
        if path.is_symlink():
            raise ValueError("S40 refuses symlinked worktree paths: " + rel)
    if not path.resolve(strict=False).is_relative_to(repo):
        raise ValueError("S40 path escapes the selected worktree")
    return path


def planned_changes(repository: Path) -> dict[str, tuple[bytes | None, bytes]]:
    root = repository.resolve(strict=True)
    if not (root / ".git").exists():
        raise ValueError("S40 must be installed into a Git worktree")
    for rel in REQUIRED:
        if not checked(root, rel).is_file():
            raise ValueError("S40 requires merged S37-S39 foundation: " + rel)
    changes: dict[str, tuple[bytes | None, bytes]] = {}
    for rel in MODIFIED:
        target = checked(root, rel)
        if not target.is_file():
            raise ValueError("S40 tracked source missing: " + rel)
        old = target.read_bytes()
        try:
            new = transform(rel, old.decode("utf-8")).encode("utf-8")
        except UnicodeError as exc:
            raise ValueError("S40 requires UTF-8 text sources") from exc
        if old != new:
            changes[rel] = old, new
    for rel in NEW:
        target = checked(root, rel)
        packaged = PACKAGE / rel
        if not packaged.is_file() or packaged.is_symlink():
            raise ValueError("S40 bundle incomplete: " + rel)
        wanted = packaged.read_bytes()
        if target.exists():
            if not target.is_file() or target.read_bytes() != wanted:
                raise ValueError("S40 refuses to replace an existing new file: " + rel)
        else:
            changes[rel] = None, wanted
    return changes


def git_private_backup_root(repo: Path) -> Path:
    result = subprocess.run(
        ["git", "-C", str(repo), "rev-parse", "--git-path", "potbot-patches/s40-agent-xpra"],
        check=True, capture_output=True, text=True,
    ).stdout.strip()
    path = Path(result)
    if not path.is_absolute():
        path = repo / path
    if path.is_symlink():
        raise ValueError("S40 backup root is symlinked")
    path.mkdir(mode=0o700, parents=True, exist_ok=True)
    return path.resolve(strict=True)


def install(repo: Path, changes: dict[str, tuple[bytes | None, bytes]]) -> None:
    """Stage all changes first; recover safely after a partial filesystem failure."""
    backup = git_private_backup_root(repo)
    staged: list[tuple[Path, Path, bytes | None, bytes]] = []
    try:
        for rel, (old, new) in changes.items():
            dest = checked(repo, rel)
            if old is None:
                if dest.exists():
                    raise ValueError("S40 new path changed during preflight: " + rel)
            elif not dest.is_file() or dest.read_bytes() != old:
                raise ValueError("S40 concurrent worktree change: " + rel)
            if old is not None:
                original = checked(backup, rel + ".original")
                original.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
                if not original.exists():
                    with original.open("xb") as output:
                        output.write(old)
                        output.flush()
                        os.fsync(output.fileno())
                elif original.is_symlink():
                    raise ValueError("S40 backup was redirected")
                # A backup from an earlier, partial S40 attempt must never be
                # overwritten by a newer snapshot during recovery.
            dest.parent.mkdir(parents=True, exist_ok=True)
            tmp = dest.with_name(".potbot-s40-pending-" + dest.name)
            if tmp.exists() or tmp.is_symlink():
                raise ValueError("S40 stale staging file requires reconciliation")
            with tmp.open("xb") as output:
                output.write(new)
                output.flush()
                os.fsync(output.fileno())
            tmp.chmod(stat.S_IMODE(dest.stat().st_mode) if old is not None else 0o644)
            staged.append((dest, tmp, old, new))
        for dest, tmp, old, new in staged:
            if old is None:
                if dest.exists():
                    raise ValueError("S40 target was created during install")
            elif dest.read_bytes() != old:
                raise ValueError("S40 worktree changed after staging")
            os.replace(tmp, dest)
    finally:
        for _, tmp, _, _ in staged:
            if tmp.exists():
                tmp.unlink()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repository", type=Path)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args(argv)
    try:
        root = args.repository.resolve(strict=True)
        changes = planned_changes(root)
        if not args.dry_run:
            install(root, changes)
        print(json.dumps({"stage": "s40", "dry_run": args.dry_run,
                          "modified": [x for x in changes if x in MODIFIED],
                          "created": [x for x in changes if x in NEW],
                          "changes": len(changes)}, sort_keys=True))
        return 0
    except (ValueError, OSError, RuntimeError, subprocess.CalledProcessError) as exc:
        print("S40 installation refused: " + str(exc), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
