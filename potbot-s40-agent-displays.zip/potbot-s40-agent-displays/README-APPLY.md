# Potbot S40 — Private Xpra displays per agent

This ZIP targets GitHub `main` at **`13f9b599a39da8e151106f680709de1c37f83061`** (merged S39). No `git pull`, `git reset`, pre-existing branch, Docker execution or GitHub write permission is required.

## PowerShell from the Potbot repository

Extract the ZIP alongside `potbot`, then run:

```powershell
Expand-Archive ..\potbot-s40-agent-displays.zip -DestinationPath .. -Force
python ..\potbot-s40-agent-displays\install.py . --dry-run
python ..\potbot-s40-agent-displays\install.py .
git diff --stat
```

Installer **preflights every tracked source anchor** and every new file before writing. Existing source backups live under Git's private metadata in `potbot-patches/s40-agent-xpra`. It preserves CRLF, rejects symlinks, malformed source, and divergent new files, and supports repeat applications. If dry-run fails, **do not force-apply**; inspect the source error and reconcile the changed anchor first.

## Main changes

- `agent_xpra_displays.py`: host-only agent display pool, distinct Xpra/Xdummy/Xauth instances and a narrowed bwrap launch with a *private* `/home` tmpfs and only one agent's real home bind.
- `XpraApplicationSupervisor.start("controlled-browser", agent_id=...)`: host-only admission with one live browser per agent; public HTTP cannot select `agent_id`.
- Host-issued agent reservations and `BrowserControlService` agent-ID revalidation on every command.
- `AgentXpraSandboxBackend`: ProcessSupervisor-compatible adapter for existing operator syscall/process/file telemetry (not a bypass to native subprocesses).
- Optional host policy `agentDisplays` with a separate, pre-provisioned operator-private root. S39 shared-display legacy branch remains unchanged.
- Unit tests, qualified-host acceptance script and S40 GitHub Actions source checks.

No workspace browser can obtain another agent's Xpra cookie or X socket just by obtaining the workspace X11 display credential **provided the target host passes the mandatory live qualification tests**. A single display still has the ordinary X11 shared-client trust model; this patch removes cross-agent display sharing instead of attempting to filter individual X11 requests.

## Next host action

Review [S40 technical specification](docs/implementation/41-s40-agent-xpra-isolation.md) and prepare an operator-private `agentDisplays.root` directory on Linux/WSL2 (owner: operator UID, mode 0700), registered agent homes, the pinned immutable rootfs and the real operator monitor. After applying the patch, run:

```bash
PYTHONPATH=src pytest -q \
  tests/unit/test_agent_xpra_displays_s40.py \
  tests/unit/test_agent_xpra_supervisor_s40.py \
  tests/unit/test_browser_s39.py \
  tests/unit/test_browser_s38.py \
  tests/unit/test_browser_cogs_s37.py
```

For **real Xpra/guest-kernel qualification**, use `tests/acceptance/xpra_agent_isolation_s40.py` with host-specific paths/UUIDs. That test must not be replaced by a fake. This package does not claim live host acceptance or a complete per-agent native Xpra HTML5 viewer. Dedicated per-stream Xpra transport + frontend display namespace is next-stage work.

## Code delivery

The GitHub connector has read access but rejected branch creation with HTTP 403. **No remote commit was created**. This bundle modifies your local worktree only.
