# Potbot Xpra controlled browser patch

Prepared against `kieransimkin/potbot` main at
`428d397a3f3e2676e44b2d22ddcde3265922b1d9` (25 October 2026).

This is a **worktree patch bundle**, not an applied GitHub commit. GitHub
repository write APIs returned HTTP 403 for the connected account.

## Apply

Extract this archive, then in WSL/Linux (Python 3.12+ available):

```bash
python3 potbot-xpra-browser-control/install.py /path/to/your/potbot
cd /path/to/your/potbot
git diff --check
git diff --stat
PYTHONPATH=src python -m pytest -q tests/unit/test_xpra_browser_control.py tests/unit/test_xpra_browser_worker.py tests/unit/test_xpra_application_sessions.py
cd frontend && npm test && npm run typecheck && npm run build
```

The installer checks **unique anchors** in seven current source files and
refuses conflicting existing new files; it does not launch a browser or use
network APIs. Back up or commit your existing work first. An already patched
file with identical content is unchanged on reapplication.

The new `sandbox/compose.build.yaml` uses the repository root as build context,
so the static browser worker source can be copied into the immutable rootfs.
Rebuild, sign, qualify and pin this image through the **existing** sandbox
pipeline. Operator GUI launch policy must explicitly admit `controlled-browser`
(see `docs/ui/xpra-controlled-browser.md`). No direct host launch fallback.

If main changed and an anchor is no longer unique, don't force the installer:
reconcile against the upstream diffs and rerun the relevant tests.

## Contents

- `xpra_browser_worker.py`: Playwright/Patchright+stealth, scoped CDP/DevTools,
  direct browser mouse/keyboard, accessibility tree, screenshot sampling.
- `xpra_browser_control.py`: timeout/fencing-aware private stdio RPC.
- `BrowserInspector.tsx`: picker, semantic inspection, screenshots, ARIA controls.
- `xpra-browser.ts` and `routes/route.ts`: authenticated, workspace-scoped proxy.
- Tests, local HTML fixture, operator setup and qualification guide.
- `install.py`: deterministic worktree edits to existing Xpra, UI, CI and image sources.

### Current limits

External network requests are blocked by the existing sandbox; a separately
qualified workspace network proxy will be required to browse remote websites.
No real-Xpra/Chromium acceptance test was executed in this environment. Agent
SYN Cog registration and persistent screenshot/trace evidence are follow-up
work; this patch exposes the browser to the operator UI and private relay.
