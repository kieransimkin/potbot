#!/usr/bin/env python3
"""Apply the reviewed Xpra controlled-browser patch to a Potbot worktree.

Fail closed on mismatched anchors or conflicting files. Does not run installs,
execute browser code, touch /etc/ai or mutate outside the selected checkout.
"""
from __future__ import annotations

import argparse
from pathlib import Path

PAYLOAD = Path(__file__).parent


def patch_one(content: str, old: str, new: str, label: str) -> str:
    if new in content:
        return content
    if content.count(old) != 1:
        raise RuntimeError(f"{label}: source drift; expected unique anchor, found {content.count(old)}")
    return content.replace(old, new, 1)


def changes(original: dict[str, str]) -> dict[str, str]:
    result = original.copy()
    path = "src/potbot/tools/xpra_app_sessions.py"
    source = result[path]
    source = patch_one(source,
        '        self.detached = False\n        self.indeterminate = False\n',
        '        self.detached = False\n        self.indeterminate = False\n        self.browser_control: Any = None\n', path)
    source = patch_one(source,
        '                process = self.popen(launch.argv, stdin=subprocess.DEVNULL,\n                                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,\n',
        '                controlled_browser = kind == "controlled-browser"\n'
        '                process = self.popen(launch.argv,\n'
        '                                     stdin=subprocess.PIPE if controlled_browser else subprocess.DEVNULL,\n'
        '                                     stdout=subprocess.PIPE if controlled_browser else subprocess.DEVNULL,\n'
        '                                     stderr=subprocess.DEVNULL,\n', path)
    source = patch_one(source,
        '                app = _App(uuid4().hex, self.recipes[kind], process, launch.identity)\n                self._apps[app.id] = app\n',
        '                app = _App(uuid4().hex, self.recipes[kind], process, launch.identity)\n'
        '                if controlled_browser:\n'
        '                    from potbot.tools.xpra_browser_control import BrowserControlChannel\n'
        '                    app.browser_control = BrowserControlChannel(process)\n'
        '                self._apps[app.id] = app\n', path)
    source = patch_one(source,
        '        if proc.poll() is not None:\n            return\n        try:\n            os.killpg(proc.pid, signal.SIGTERM)\n',
        '        if proc.poll() is not None:\n            if app.browser_control is not None:\n                app.browser_control.close()\n            return\n        try:\n            os.killpg(proc.pid, signal.SIGTERM)\n', path)
    source = patch_one(source,
        '            except subprocess.TimeoutExpired:\n                app.indeterminate = True\n\n    def _watch(self) -> None:\n',
        '            except subprocess.TimeoutExpired:\n                app.indeterminate = True\n        if app.browser_control is not None:\n            app.browser_control.close()\n\n    def _watch(self) -> None:\n', path)
    source = patch_one(source,
        '    def detach(self, identifier: str) -> dict[str, Any]:\n',
        '    def browser_command(self, identifier: str, command: object) -> dict[str, Any]:\n'
        '        """Read/control only the Chromium belonging to an admitted app session."""\n'
        '        with self._lock:\n'
        '            app = self._get(identifier)\n'
        '            if (app.recipe.kind != "controlled-browser" or app.process.poll() is not None\n'
        '                    or app.indeterminate or self._guard is None or self._guard.fenced\n'
        '                    or app.browser_control is None):\n'
        '                raise ScopeDeniedError("browser operation outside admitted live session")\n'
        '            channel = app.browser_control\n'
        '        try:\n'
        '            return channel.call(command)\n'
        '        except StateMismatchError:\n'
        '            with self._lock:\n'
        '                app.indeterminate = True\n'
        '                self._terminate(app)\n'
        '                self._settle()\n'
        '            raise\n\n'
        '    def detach(self, identifier: str) -> dict[str, Any]:\n', path)
    result[path] = source

    path = "src/potbot/tools/x11_workspace_server.py"
    source = result[path]
    anchor = '    @app.post("/v1/xpra/apps/{session_id}/{operation}")\n'
    insertion = '''    @app.post("/v1/xpra/apps/{session_id}/browser")
    async def browser_command(session_id: str, request: Request,
                              authorization: str | None = Header(default=None)) -> JSONResponse:
        authenticate(authorization)
        if apps is None:
            raise HTTPException(503, "qualified browser launcher not configured")
        if int(request.headers.get("content-length", "0") or "0") > 4096:
            raise HTTPException(413, "browser request too large")
        body = await request.body()
        if len(body) > 4096:
            raise HTTPException(413, "browser request too large")
        try:
            data = json.loads(body)
            from potbot.tools.xpra_browser_worker import validate_command
            validate_command(data)
        except (ValueError, TypeError, UnicodeError):
            raise HTTPException(409, "unapproved browser operation") from None
        try:
            result = apps.browser_command(session_id, data)
        except (ValueError, RuntimeError, DomainError, OSError):
            # The operation may have completed just before a disconnect.
            # Do not retry state-changing commands automatically.
            raise HTTPException(409, "browser command rejected or indeterminate") from None
        return JSONResponse({"workspaceId": str(server.workspace_id), "result": result},
                            headers={"Cache-Control": "private, no-store"})

'''
    result[path] = patch_one(source, anchor, insertion + anchor, path)

    path = "sandbox/compose.build.yaml"
    source = result[path]
    source = patch_one(source,
        '      context: .\n      dockerfile: image/Dockerfile\n',
        '      context: ..\n      dockerfile: sandbox/image/Dockerfile\n', path)
    result[path] = source

    path = "sandbox/image/Dockerfile"
    source = result[path]
    source = patch_one(source,
        '        bash ca-certificates coreutils findutils grep sed git gzip tar util-linux \\\n',
        '        bash ca-certificates coreutils findutils grep sed git gzip tar util-linux \\\n'
        '        python3 python3-venv chromium fonts-liberation \\\n', path)
    source = patch_one(source,
        'WORKDIR /home\nCMD ["/bin/bash"]\n',
        '''# Xpra-controlled browser is part of the separately qualified immutable image.
# A copied Python executable keeps the guest path inside the rootfs admission.
RUN python3 -m venv --copies /opt/potbot/browser \\
    && /opt/potbot/browser/bin/pip install --no-cache-dir \\
         playwright==1.64.1 patchright==1.64.2 playwright-stealth==2.0.3
COPY src/potbot/tools/xpra_browser_worker.py /opt/potbot/browser_worker.py
WORKDIR /home
CMD ["/bin/bash"]
''', path)
    result[path] = source

    path = "frontend/src/components/Panels.tsx"
    source = result[path]
    source = patch_one(source,
        'import { useWorkspace } from "./WorkspaceContext";\n',
        'import { useWorkspace } from "./WorkspaceContext";\nimport { BrowserInspector } from "./BrowserInspector";\n', path)
    source = patch_one(source,
        '    <div className="empty-panel"><h2>Controlled browser</h2>\n',
        '    <div className="empty-panel"><h2>Controlled browser</h2>\n      <BrowserInspector />\n', path)
    result[path] = source

    path = "frontend/src/app/globals.css"
    source = result[path]
    style = '''
/* Operator-only native Chromium DevTools/ARIA inspector. */
.browser-inspector { width:min(100%,850px); padding:12px; margin:10px auto;
  text-align:left; border:1px solid var(--border, #455268); border-radius:10px; }
.browser-inspector-controls { display:grid; grid-template-columns:repeat(auto-fit,minmax(160px,1fr)); gap:8px;
  align-items:center; margin:12px 0; }
.browser-inspector-controls button { min-height:32px; }
.browser-inspector-controls input, .browser-inspector-controls select { min-width:0; width:100%; }
.browser-inspector-preview { max-width:100%; height:auto; object-fit:contain; border-radius:6px; }
.browser-inspector-result { white-space:pre-wrap; overflow-wrap:anywhere; max-height:350px;
  overflow:auto; font-size:12px; text-align:left; }
'''
    if style not in source:
        source += style
    result[path] = source

    path = ".github/workflows/xpra-native-window-acceptance.yml"
    source = result[path]
    source = patch_one(source,
        "      - 'src/potbot/tools/xpra_app_sessions.py'\n",
        "      - 'src/potbot/tools/xpra_app_sessions.py'\n"
        "      - 'src/potbot/tools/xpra_browser_*.py'\n"
        "      - 'tests/unit/test_xpra_browser_control.py'\n", path)
    source = patch_one(source,
        '          tests/unit/test_xpra_application_sessions.py\n',
        '          tests/unit/test_xpra_application_sessions.py\n'
        '          tests/unit/test_xpra_browser_control.py\n', path)
    result[path] = source
    return result


def run(root: Path) -> None:
    base = root.resolve(strict=True)
    paths = [
        "src/potbot/tools/xpra_app_sessions.py", "src/potbot/tools/x11_workspace_server.py",
        "sandbox/compose.build.yaml", "sandbox/image/Dockerfile",
        "frontend/src/components/Panels.tsx", "frontend/src/app/globals.css",
        ".github/workflows/xpra-native-window-acceptance.yml",
    ]
    for name in paths:
        selected = base / name
        if selected.is_symlink() or not selected.resolve(strict=True).is_relative_to(base):
            raise RuntimeError(f"{name}: existing file resolves outside worktree")
    originals = {name: (base / name).read_text(encoding="utf-8") for name in paths}
    updated = changes(originals)  # Fail before any writes if source drifted.
    files = {
        "src/potbot/tools/xpra_browser_worker.py": "xpra_browser_worker.py",
        "src/potbot/tools/xpra_browser_control.py": "xpra_browser_control.py",
        "frontend/src/components/BrowserInspector.tsx": "BrowserInspector.tsx",
        "frontend/src/lib/server/xpra-browser.ts": "xpra-browser.ts",
        "frontend/src/app/api/ui/xpra/apps/[sessionId]/browser/route.ts": "routes/route.ts",
        "tests/unit/test_xpra_browser_control.py": "test_xpra_browser_control.py",
        "tests/unit/test_xpra_browser_worker.py": "test_xpra_browser_worker.py",
        "frontend/tests/xpra-browser.test.mjs": "xpra-browser.test.mjs",
        "docs/ui/xpra-controlled-browser.md": "xpra-controlled-browser.md",
        "tests/fixtures/browser-inspector.html": "fixtures/inspector-fixture.html",
    }
    for name, payload in files.items():
        target = base / name
        body = (PAYLOAD / payload).read_text(encoding="utf-8")
        if target.exists() and target.read_text(encoding="utf-8") != body:
            raise RuntimeError(f"{name}: existing target differs; refusing overwrite")
        if target.is_symlink() or not target.parent.resolve().is_relative_to(base):
            raise RuntimeError(f"{name}: target resolves outside worktree")
    for name, body in updated.items():
        (base / name).write_text(body, encoding="utf-8")
    for name, payload in files.items():
        target = base / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text((PAYLOAD / payload).read_text(encoding="utf-8"), encoding="utf-8")
    print(f"Applied controlled browser patch in {base} (7 patched + {len(files)} added files)")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repo", type=Path, help="Path to the existing potbot repository checkout")
    run(parser.parse_args().repo)
