# Potbot Phase 3 update — version 0.3.0

Base: `kieransimkin/potbot` main, commit
`ff5510e75a16e9fa8b2a8c4a3008e4a568a0ad87` (Database update).

This delivery completes all 17 approved Phase 3 steps: P022–P034 and P154–P157.
It contains a Git patch, the complete updated files as an overlay, machine-readable
implementation/verification records, and the sanitized final verification logs.
It does not contain model weights, database data, runtime secrets, or a Git repository.

## Apply

Use a clean checkout of the base commit. From that repository, after extracting this
ZIP, substitute the actual path to the patch:

```bash
git switch -c phase-3-repository-execution
git apply --check /path/to/potbot-phase-3-update/potbot-phase-3.patch
git apply /path/to/potbot-phase-3-update/potbot-phase-3.patch
git diff --stat
```

These commands work with Git on Windows too; quote a patch path containing spaces.
If `git apply --check` reports a conflict, resolve it against your local changes
before applying. The `files/` directory provides the same changed files for manual
review or controlled overlay. This archive is an update to the stated baseline,
not a standalone checkout. No remote branch or commit has been published.

## Install and migrate

```bash
uv sync --locked --extra postgres --extra semantics --dev
uv run --locked potbot info
```

Keep `--extra embeddings` in the sync command if this installation uses the local
Qwen encoder. Before upgrading an existing database, retain its normal backup,
stop old application writers, set `POTBOT_ADMIN_DSN` to the intended installation,
and run:

```bash
uv run --locked potbot admin --schema potbot migrate
```

Migrations 6–8 are additive. Historical migrations 1–5 and existing configuration,
packet, evidence, named-vector and accounting identities are preserved. Historical
tasks receive no implicit semantic release pin; new execution needs a supported pin.
Use the restricted application login in `POTBOT_DSN` for ordinary operations.

## What is available

- Exact repository snapshots, dirty/untracked inputs, candidate directories and leases.
- Registered, budgeted tool execution through an actual Linux Bubblewrap/seccomp sandbox.
- Separate stdout/stderr artifacts, result-state lineage, deadlines and cancellation.
- Private completion receipts, fenced recovery claims and conservative lost-ack recovery.
- First-class information needs with immutable revisions and evidence references.
- Pinned semantic catalogs, exact typed values, bounded proposal validation and task/packet pins.
- Hard preparation/inference supervision for the existing standard Qwen embedding profile.
- `potbot execution prepare`, `run`, `inspect`, `reconcile` and `resume`.

Read `files/docs/phase-3.md` for the complete CLI/API workflow and limits. After
applying the update, the same guide is at `docs/phase-3.md` in the repository.

## Verification

The combined gate passed all 459 tests: 342 core/Git tests, 87 PostgreSQL tests,
and 30 real sandbox tests. Ruff, formatting, mypy, wheel build, installation into
a clean environment, installed CLI help and bundled semantic catalog checks passed.
A separate real pinned Qwen smoke returned finite normalized 1024-dimensional
vectors and the expected two retrieval results with the existing profile hash.

The patch was applied to an independent clean clone of the exact base commit;
every distributable file then matched the tested source tree byte-for-byte.
`manifest.json` records changed-file and patch SHA256 values. `source-files.sha256`
in the overlay covers the complete repository source after application.

To reproduce the combined gate, provide the explicit disposable test database DSN
and a host with qualified Linux namespaces, Bubblewrap, libseccomp and `prlimit`:

```bash
uv run --locked python scripts/check.py --with-postgres --with-sandbox
```

The qualified process backend is Linux x86_64. Native Windows/macOS execution,
aggregate memory/process quotas, submodule materialization, live network services
inside candidates, and general dependency installation are not included. There is
no unrestricted host fallback. Missing or mismatched completion proof keeps work
indeterminate and prevents blind replay; this is not an exactly-once process claim.

Autonomous patch production, reasoning/coding inference, multi-model tree selection,
IBM/DanceFlow MCP transports, live web/library/workflow discovery, learned memory
admission and custom embeddings remain planned. The next phase is Phase 4, “The first
verified patch,” steps P035–P040.
