"""potbot foundation, with no import-time service connections."""

__version__ = "0.3.0"
