# potbot

An evidence-driven, multi-model coding agent, built in stages from the architecture
and implementation plan in `docs/`.

**Implemented: Phases 1–3, including P022–P034 and P154–P157.** Tasks, contracts,
evidence, artifacts, worker jobs, budgets, configuration, environment identities, and
model invocation records are durable. Potbot can capture a local Git repository,
materialize isolated candidates, execute registered tools under a qualified Linux
sandbox, and reconcile interrupted runs. The standard local Qwen encoder indexes
explicit sources and searches PostgreSQL with pgvector under hard process supervision.
Pinned semantic catalogs and bounded typed proposal validation are also implemented.

The current execution flow uses operator-selected tools and scripted proposals.
Multi-model reasoning-tree selection, reasoning/coding inference, learned memory
admission, live web discovery, IBM MCP, DanceFlow MCP, and the custom semantic embedding
space remain later stages. The five default reasoning and coding models are registered
as **unqualified catalog entries**; a name is never treated as a tested deployment.

## Install and check

Use Python 3.12, Git, and [uv](https://docs.astral.sh/uv/):

```bash
uv sync --locked --extra postgres --extra semantics --dev
uv run --locked potbot info
uv run --locked python scripts/check.py
```

The core package has no mandatory third-party runtime dependencies. The PostgreSQL
driver, semantic validation, and local encoder are separate extras. Domain imports and
CLI help need neither model weights nor running services. `uv.lock` pins the complete
dependency resolution.

For the real PostgreSQL suite and Linux process-isolation acceptance suite, install
Bubblewrap, libseccomp, and `prlimit` from the host's packages. On Debian/Ubuntu:

```bash
sudo apt-get install bubblewrap libseccomp2 util-linux
```

The host must permit Bubblewrap's user, mount, PID, and network namespaces. Then run:

```bash
docker compose up --detach --wait
export POTBOT_TEST_DSN='postgresql://potbot_test:potbot_test_only@127.0.0.1:55432/potbot_test'
uv run --locked python scripts/check.py --with-postgres --with-sandbox
docker compose down --volumes
```

`compose.yaml` is a disposable test database with temporary storage. Use persistent
PostgreSQL and an artifact directory on persistent storage for retained tasks.
Selecting PostgreSQL tests without a usable explicit test DSN fails; tests never
silently substitute an in-memory database. Selecting sandbox tests requires a working
isolation backend; unavailable isolation fails closed. CI requests both suites. Omit
`--with-sandbox` for the SQL-only gate on a host without qualified process isolation.

## Work with tasks

Provision the application schema, a workspace, and a restricted database principal
with `potbot admin`. Then submit and inspect tasks through `potbot task`. The CLI and
versioned HTTP adapter share the same service operations and workspace checks.

```bash
uv run --locked potbot admin --help
uv run --locked potbot task --help
uv run --locked potbot worker --help
```

The [Phase 2 guide](docs/phase-2.md) contains provisioning, task submission,
worker recovery, API, configuration, and acceptance-test instructions. A valid starter
contract is in [examples/task-contract.json](examples/task-contract.json).

## Repository capture and controlled execution

The [Phase 3 guide](docs/phase-3.md) covers application migrations 6–8 and the complete
`prepare`, `run`, `inspect`, `reconcile`, and `resume` workflow:

```bash
uv run --locked potbot execution --help
```

Snapshots preserve tracked changes plus explicitly included untracked/generated inputs
without modifying the source repository. Candidates have ownership markers and fenced
single-writer leases. The default CLI tools inspect files, compile Python, and run
Python `unittest` discovery. Their captured outputs, actual input/result states, and
usage remain inspectable after restart.

Run receipts are kept outside candidates. A matching stopped-process receipt can
reconcile a lost completion acknowledgment; missing or inconsistent evidence leaves
the workspace quarantined and prevents blind replay. `execution resume` reconstructs
durable state and accounting without starting a command or changing task lifecycle.

The qualified backend is **Linux Bubblewrap plus seccomp**. It denies direct networking
and access to unmounted host files; the supervisor has no unrestricted host fallback.
CPU, address-space, file-size, and descriptor limits are per process. Aggregate memory
and process-count quotas, native Windows/macOS execution, submodule materialization,
and general dependency installation are outside this delivery.

## Standard local vector embeddings

The reference integration uses **Qwen/Qwen3-Embedding-0.6B**, pinned to revision
`97b0c614be4d77ee51c0cef4e5f07c00f9eb65b3`, with **1,024 dimensions**, last-token pooling,
L2 normalization, and cosine distance. It runs locally on CPU in float32. Setup is an
explicit download; encoding never falls back to a remote service.

```bash
uv sync --locked --extra postgres --extra semantics --extra embeddings --dev
uv run --locked potbot embedding setup --model-dir models/qwen3-embedding-0.6b
uv run --locked potbot embedding smoke --model-dir models/qwen3-embedding-0.6b --timeout-ms 120000
```

The pinned weight/tokenizer files occupy about 1.21 GB on disk; runtime memory is
additional. Model files stay outside Git. For an existing local installation, run
`smoke` directly; setup downloads only into a new directory. Supervised encoding and
the smoke command require the qualified Linux sandbox described above. The deadline
covers tokenizer/model preparation and inference; a timed-out, cancelled, or unconfirmed
worker cannot publish a late vector. Confirmed usage is charged, confirmed unused capacity
is released, and uncertain usage remains held for reconciliation.

The [embedding guide](docs/embeddings.md) explains source registration, budgeted indexing,
exact filtered search, retirement, and the opt-in live SQL test. This first integration
uses explicit sources and exact search; automatic repository chunking, hybrid ranking,
ANN indexes, and custom learned embeddings are later work.

Vectors have **named representations**, starting with `general_text`. Indexing and
search select both a name and an exact immutable space; artifacts expose a typed
`named_embeddings` manifest that retains source and profile provenance. The
[named-embedding guide](docs/named-embeddings.md) covers application migration 5,
additional named views, the JSON schema and the coordinated upgrade procedure.

## Semantic types and release identities

The committed [vocabulary package](vocab/) supplies 45 data types, including six
abstract families, plus entity types, predicates, concepts, and retrieval profiles.
The loader checks the exact catalog, explicit subtype graph, local schema references,
and release hashes. Typed literals preserve distinctions between booleans, integers,
decimals, strings, null, absent, and unresolved values.

New tasks and context packets freeze their semantic release identities. Selecting a
new release does not rewrite historical configurations or packets. Structural
validation leaves an envelope as a proposal: entity resolution, truth adjudication,
guard evaluation, and learned semantic classification remain later work. See the
[semantic API and compatibility notes](docs/phase-3.md#semantic-contracts-and-release-pins).

## Package boundaries

| Package | Responsibility |
| --- | --- |
| `potbot.domain` | Immutable contracts, provenance, configuration, identity, error taxonomy |
| `potbot.persistence` | Migrations, scoped SQL transactions, artifacts, evidence, outbox, fenced workers |
| `potbot.controller` | Task lifecycle, contracts, budgets, durable actions and information needs, reuse policy |
| `potbot.api` | Versioned task operations, development authentication, HTTP and CLI adapters |
| `potbot.models` | Deployment registry, resolved configuration, environments, packets and invocation records |
| `potbot.memory` | Supervised local encoding, source versions, named vectors and exact retrieval |
| `potbot.semantics` | Immutable semantic catalogs, typed proposal validation and consumer release pins |
| `potbot.evaluation` | Real Git fixtures and sanitized verification diagnostics |
| `potbot.tools` | Repository snapshots, candidate leases, tool admission, Linux isolation, captures and recovery |

## Reuse before implementation

The standard reasoning policy requires discovery of existing libraries, tools, and
internal workflows before proposing new code. A structured review records evidence
and chooses reuse, adaptation, or a new implementation. The contracts and deterministic
gate are implemented; later tool adapters will perform live discovery and supply
trusted receipts. See [docs/reasoning-policy.md](docs/reasoning-policy.md).

The Phase 1 fixture instructions remain in [docs/phase-1.md](docs/phase-1.md).
